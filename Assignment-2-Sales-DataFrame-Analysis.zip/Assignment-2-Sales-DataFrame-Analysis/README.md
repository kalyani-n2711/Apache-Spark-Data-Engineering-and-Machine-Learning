# Assignment 2: Sales Data Processing and Business Intelligence Using Spark DataFrames

## 1. Overview & Scenario
A retail organization tracks sales transactions across 6 product categories and 8 Indian cities. This project uses **Scala 2.12.18** and **Apache Spark 3.5.3 DataFrames** to enforce an explicit `StructType` schema, audit and clean missing or invalid records, compute business intelligence aggregations, benchmark RDD vs. DataFrame execution, and examine **Catalyst Optimizer** plans.

> **Dataset Note:** `data/sales_transactions_synthetic_10000.csv` is a **synthetic** 10,000-row retail transaction dataset (`Transaction_ID`, `Product_Name`, `Category`, `Store_Location`, `Quantity_Sold`, `Unit_Price`, `Transaction_Date`).

---

## 2. Project Structure

```text
Assignment-2-Sales-DataFrame-Analysis/
├── data/
│   └── sales_transactions_synthetic_10000.csv
├── project/build.properties
├── scripts/generate_charts.py
├── src/main/scala/edu/university/df/
│   └── SalesDataFrameAnalysis.scala    # Spark DataFrame BI & Catalyst inspection app
├── build.sbt
├── pom.xml
├── run.ps1
└── README.md
```

---

## 3. Data Quality Audit & Cleaning

| Validation Check | Rows Flagged | Handling |
|---|---:|---|
| Null `Quantity_Sold` | 20 | Exported to `outputs/invalid_or_missing_rows.csv` & filtered out |
| Null `Unit_Price` | 15 | Exported to `outputs/invalid_or_missing_rows.csv` & filtered out |
| Non-positive `Quantity_Sold <= 0` | 10 | Exported to `outputs/invalid_or_missing_rows.csv` & filtered out |
| Non-positive `Unit_Price <= 0` (min `-5416.0`) | 10 | Exported to `outputs/invalid_or_missing_rows.csv` & filtered out |
| **Total Clean Valid Transactions** | **9,945 / 10,000** | **`99.45%` retained for BI analysis** |

---

## 4. Analytical Results (9,945 Clean Transactions)

- **Grand Total Revenue:** `INR 118,658,728.00` (~₹11.87 Cr)
- **Total Units Sold:** `78,877`
- **Average Order Value:** `INR 11,931.50`
- **Maximum Single Transaction:** `INR 89,790.00` (`TXN003023`, Keyboard, Chennai, `15 × ₹5,986`)
- **High-Value Transactions (`Total_Sales > ₹10,000`):** `3,573` transactions (`35.93%` of valid orders)

### 4.1 Revenue by Product Category
| Category | Transactions | Total Units | Total Revenue (INR) | Avg Order (INR) | Share (%) |
|---|---:|---:|---:|---:|---:|
| **Electronics** | 1,758 | 13,939 | **44,058,077.00** | 25,061.48 | **37.13%** |
| **Home & Kitchen** | 1,597 | 12,614 | 31,968,867.00 | 20,018.08 | 26.94% |
| **Clothing** | 1,557 | 12,355 | 20,070,322.00 | 12,890.38 | 16.91% |
| **Groceries** | 2,447 | 19,254 | 8,935,189.00 | 3,651.49 | 7.53% |
| **Beauty** | 1,415 | 11,249 | 8,814,101.00 | 6,229.05 | 7.43% |
| **Stationery** | 1,171 | 9,466 | 4,812,172.00 | 4,109.46 | 4.06% |

### 4.2 Top 5 Best-Selling Products
- **By Total Revenue:** `Headphones` (`₹7,767,870`), `USB-C Hub` (`₹7,667,419`), `Keyboard` (`₹7,544,755`), `Bluetooth Speaker` (`₹7,317,670`), `Power Bank` (`₹6,909,039`).
- **By Units Sold:** `Coffee Jar` (`3,371` units), `Wheat Flour 5kg` (`3,342`), `Tea Pack` (`3,321`), `Rice 5kg` (`3,102`), `Cooking Oil 1L` (`3,085`).

### 4.3 Location-wise Revenue
| Store Location | Transactions | Total Units | Total Revenue (INR) | Share (%) |
|---|---:|---:|---:|---:|
| **Jaipur** | 1,270 | 10,142 | **15,516,183.00** | **13.08%** |
| **Bengaluru** | 1,235 | 9,817 | 15,404,614.00 | 12.98% |
| **Mumbai** | 1,268 | 10,255 | 15,324,503.00 | 12.91% |
| **Chennai** | 1,282 | 9,963 | 14,826,676.00 | 12.50% |
| **Pune** | 1,245 | 10,032 | 14,610,064.00 | 12.31% |
| **Faridabad** | 1,185 | 9,441 | 14,577,122.00 | 12.28% |
| **Hyderabad** | 1,236 | 9,697 | 14,382,452.00 | 12.12% |
| **Delhi** | 1,224 | 9,530 | 14,017,114.00 | 11.81% |

---

## 5. RDD vs. DataFrame Comparison & Catalyst Optimization

| Dimension | Spark RDD | Spark DataFrame |
|---|---|---|
| **Abstraction** | Untyped/typed JVM objects; opaque lambdas | Schema-enforced (`StructType`) relational columns |
| **Memory Layout** | Standard JVM heap objects | **Tungsten** off-heap binary `UnsafeRow` & columnar compression |
| **Optimization** | None (manual user optimization) | **Catalyst Optimizer** (Predicate Pushdown, Column Pruning, Constant Folding) |
| **Execution** | Row-at-a-time iterator calls | **Whole-Stage Code Generation** (fused JVM bytecode) |

### Observed Catalyst Optimization (`outputs/catalyst_execution_plans.txt`)
For the high-value (`Total_Sales > 10,000`) category query:
- **Column Pruning:** `FileScan csv [Category, Quantity_Sold, Unit_Price]` scans **only 3 of the 7 CSV columns**.
- **Predicate Pushdown:** `PushedFilters: [IsNotNull(Quantity_Sold), IsNotNull(Unit_Price), GreaterThan(Quantity_Sold,0.0), GreaterThan(Unit_Price,0.0)]`.
- **Two-Stage Aggregation:** Partial `HashAggregate` executes map-side before `Exchange hashpartitioning(Category, 8)`.
- **Empirical Timing (`10,000` rows, `624 KB`):** Cold CSV read (`RDD: 820.41 ms` vs. `DataFrame: 849.14 ms`) and 5× cached aggregation (`RDD: 450.68 ms` vs. `DataFrame: 1249.53 ms`). At `10,000`-row micro-scale, Catalyst/AQE query planning (~150–250 ms per query) dominates raw compute; at multi-million-row scale, Tungsten columnar scans and Whole-Stage Codegen dramatically outperform JVM-object RDDs.

---

## 6. How to Build and Run

```bash
cd Assignment-2-Sales-DataFrame-Analysis

# Option 1: sbt
sbt run

# Option 2: Apache Maven (Java 17)
mvn compile exec:java

# Option 3: PowerShell + Scala CLI (Windows)
.\run.ps1
```

Pass `--hold-ui 30` to keep the Spark UI live on `http://localhost:4041` for SQL DAG inspection. Run `python scripts/generate_charts.py` after execution to generate BI charts in `outputs/charts/`.
