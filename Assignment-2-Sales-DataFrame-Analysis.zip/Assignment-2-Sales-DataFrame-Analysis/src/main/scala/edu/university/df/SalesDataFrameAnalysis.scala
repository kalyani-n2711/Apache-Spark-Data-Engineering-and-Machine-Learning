//> using scala 2.12.18
//> using dep org.apache.spark::spark-core:3.5.3
//> using dep org.apache.spark::spark-sql:3.5.3
//> using javaOpt --add-opens=java.base/java.lang=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.lang.invoke=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.lang.reflect=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.io=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.net=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.nio=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util.concurrent=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.nio.ch=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.nio.cs=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.security.action=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.util.calendar=ALL-UNNAMED
//> using javaOpt --add-opens=java.security.jgss/sun.security.krb5=ALL-UNNAMED

package edu.university.df

import java.nio.charset.StandardCharsets
import java.nio.file.{Files, Path, Paths}
import java.util.concurrent.atomic.AtomicInteger
import org.apache.spark.scheduler.{SparkListener, SparkListenerJobStart}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

/**
 * Assignment 2: Sales Data Processing and Business Intelligence Using Spark DataFrames
 *
 * Implements:
 *  - Explicit StructType schema & CSV loading
 *  - Missing/invalid data audit and cleaning
 *  - Total_Sales calculation, Category revenue, Top 5 products (revenue & quantity),
 *    Location-wise revenue, High-value transactions (> INR 10,000), Monthly trend
 *  - Empirical RDD vs DataFrame execution comparison
 *  - Lazy evaluation demonstration & Catalyst Optimizer execution plan inspection
 *  - Spark UI REST API metadata export
 */
object SalesDataFrameAnalysis {

  private def resolveInputPath(cliArg: Option[String]): Path = {
    val candidates = cliArg.toSeq ++ Seq(
      "data/sales_transactions_synthetic_10000.csv",
      "Assignment-2-Sales-DataFrame-Analysis/data/sales_transactions_synthetic_10000.csv",
      "sales_transactions_synthetic_10000.csv"
    )
    candidates
      .map(p => Paths.get(p).toAbsolutePath.normalize())
      .find(Files.exists(_))
      .getOrElse {
        throw new IllegalArgumentException(
          s"Could not locate data/sales_transactions_synthetic_10000.csv. Checked: ${candidates.mkString(", ")}"
        )
      }
  }

  private def writeTextFile(path: Path, content: String): Unit = {
    Files.createDirectories(path.getParent)
    Files.write(path, content.getBytes(StandardCharsets.UTF_8))
  }

  private def escapeCsv(value: Any): String = {
    val s = if (value == null) "" else value.toString
    if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
      "\"" + s.replace("\"", "\"\"") + "\""
    } else s
  }

  private def formatTable(df: DataFrame, maxRows: Int = 15): String = {
    val cols = df.columns
    val rows = df.take(maxRows).map(r => r.toSeq.map(v => if (v == null) "null" else v.toString))
    val widths = cols.indices.map { i =>
      val dataMax = if (rows.isEmpty) 0 else rows.map(_(i).length).max
      math.min(32, math.max(cols(i).length, dataMax))
    }
    def fmtRow(cells: Seq[String]): String =
      cells.zip(widths).map { case (c, w) =>
        val clipped = if (c.length > w) c.take(w - 3) + "..." else c
        clipped.padTo(w, ' ')
      }.mkString("| ", " | ", " |")
    val sep = widths.map("-" * _).mkString("+-", "-+-", "-+")
    (Seq(sep, fmtRow(cols), sep) ++ rows.map(fmtRow) ++ Seq(sep)).mkString("\n")
  }

  private def exportDfToCsv(df: DataFrame, path: Path): Array[Row] = {
    val rows = df.collect()
    val header = df.columns.map(escapeCsv).mkString(",")
    val body = rows.map(r => r.toSeq.map(escapeCsv).mkString(","))
    writeTextFile(path, (header +: body).mkString("\n"))
    rows
  }

  def main(args: Array[String]): Unit = {
    val argList = args.toList
    val csvArg = argList.find(a => !a.startsWith("--"))
    val holdUiSeconds = argList
      .sliding(2)
      .collectFirst { case List("--hold-ui", secs) => secs.toInt }
      .getOrElse(0)

    val inputPath = resolveInputPath(csvArg)
    val projectDir =
      if (inputPath.getParent.getFileName.toString == "data") inputPath.getParent.getParent
      else inputPath.getParent
    val outputsDir = projectDir.resolve("outputs")
    Files.createDirectories(outputsDir)

    val spark = SparkSession.builder()
      .appName("Assignment2-SalesBusinessIntelligence-DataFrames")
      .master("local[*]")
      .config("spark.ui.enabled", "true")
      .config("spark.ui.port", "4041")
      .config("spark.sql.shuffle.partitions", "8")
      .getOrCreate()

    val sc = spark.sparkContext
    sc.setLogLevel("WARN")

    val jobCounter = new AtomicInteger(0)
    sc.addSparkListener(new SparkListener {
      override def onJobStart(jobStart: SparkListenerJobStart): Unit = {
        jobCounter.incrementAndGet()
      }
    })

    val report = new StringBuilder()
    def log(msg: String): Unit = {
      println(msg)
      report.append(msg).append("\n")
    }

    try {
      log("=" * 80)
      log("ASSIGNMENT 2: SALES DATA PROCESSING & BI USING APACHE SPARK DATAFRAMES")
      log("=" * 80)
      log(s"Spark Version : ${spark.version}")
      log(s"Spark Web UI  : ${sc.uiWebUrl.getOrElse("Disabled")}")
      log(s"Dataset Path  : $inputPath")

      // -----------------------------------------------------------------------
      // 1. Define explicit StructType schema & load CSV into Spark DataFrame
      // -----------------------------------------------------------------------
      val salesSchema = StructType(Seq(
        StructField("Transaction_ID", StringType, nullable = false),
        StructField("Product_Name", StringType, nullable = false),
        StructField("Category", StringType, nullable = false),
        StructField("Store_Location", StringType, nullable = false),
        StructField("Quantity_Sold", DoubleType, nullable = true),
        StructField("Unit_Price", DoubleType, nullable = true),
        StructField("Transaction_Date", DateType, nullable = true)
      ))

      val rawSalesDf = spark.read
        .option("header", "true")
        .option("dateFormat", "yyyy-MM-dd")
        .schema(salesSchema)
        .csv(inputPath.toString)
        .cache()

      val rawCount = rawSalesDf.count()
      log(s"\n--- 1. Dataset Schema & Structure (Total Raw Rows: $rawCount) ---")
      log(rawSalesDf.schema.treeString)
      log(s"Partitions: ${rawSalesDf.rdd.getNumPartitions}")
      log("Summary Statistics (Raw):")
      log(formatTable(rawSalesDf.describe("Quantity_Sold", "Unit_Price"), 10))

      // -----------------------------------------------------------------------
      // 2. Identify Missing or Invalid Values
      // -----------------------------------------------------------------------
      log("\n--- 2. Data Quality Audit: Missing & Invalid Values ---")
      val auditRow = rawSalesDf.agg(
        count(when(col("Transaction_ID").isNull || trim(col("Transaction_ID")) === "", 1)).as("null_txn_id"),
        count(when(col("Product_Name").isNull || trim(col("Product_Name")) === "", 1)).as("null_product"),
        count(when(col("Category").isNull || trim(col("Category")) === "", 1)).as("null_category"),
        count(when(col("Store_Location").isNull || trim(col("Store_Location")) === "", 1)).as("null_location"),
        count(when(col("Quantity_Sold").isNull, 1)).as("null_qty"),
        count(when(col("Unit_Price").isNull, 1)).as("null_price"),
        count(when(col("Transaction_Date").isNull, 1)).as("invalid_or_null_date"),
        count(when(col("Quantity_Sold") <= 0, 1)).as("non_positive_qty"),
        count(when(col("Unit_Price") <= 0, 1)).as("non_positive_price")
      ).first()

      log(s"  Null Transaction_ID    : ${auditRow.getAs[Long]("null_txn_id")}")
      log(s"  Null Product_Name      : ${auditRow.getAs[Long]("null_product")}")
      log(s"  Null Category          : ${auditRow.getAs[Long]("null_category")}")
      log(s"  Null Store_Location    : ${auditRow.getAs[Long]("null_location")}")
      log(s"  Null Quantity_Sold     : ${auditRow.getAs[Long]("null_qty")}")
      log(s"  Null Unit_Price        : ${auditRow.getAs[Long]("null_price")}")
      log(s"  Invalid/Null Date      : ${auditRow.getAs[Long]("invalid_or_null_date")}")
      log(s"  Non-Positive Qty (<=0) : ${auditRow.getAs[Long]("non_positive_qty")}")
      log(s"  Non-Positive Price(<=0): ${auditRow.getAs[Long]("non_positive_price")}")

      val invalidCondition =
        col("Transaction_ID").isNull || trim(col("Transaction_ID")) === "" ||
        col("Product_Name").isNull || trim(col("Product_Name")) === "" ||
        col("Category").isNull || trim(col("Category")) === "" ||
        col("Store_Location").isNull || trim(col("Store_Location")) === "" ||
        col("Quantity_Sold").isNull || col("Quantity_Sold") <= 0 ||
        col("Unit_Price").isNull || col("Unit_Price") <= 0 ||
        col("Transaction_Date").isNull

      val invalidDf = rawSalesDf
        .withColumn(
          "Issue_Reason",
          when(col("Quantity_Sold").isNull, "Missing Quantity_Sold")
            .when(col("Unit_Price").isNull, "Missing Unit_Price")
            .when(col("Quantity_Sold") <= 0, "Non-Positive Quantity_Sold")
            .when(col("Unit_Price") <= 0, "Non-Positive Unit_Price")
            .otherwise("Other Missing/Invalid Field")
        )
        .filter(invalidCondition)

      val invalidRows = exportDfToCsv(invalidDf, outputsDir.resolve("invalid_or_missing_rows.csv"))
      log(s"Total Invalid/Missing Rows Flagged & Exported: ${invalidRows.length}")

      // Clean dataset & compute Total_Sales
      val cleanSalesDf = rawSalesDf
        .filter(!invalidCondition)
        .withColumn("Quantity_Sold", col("Quantity_Sold").cast(IntegerType))
        .withColumn("Total_Sales", round(col("Quantity_Sold") * col("Unit_Price"), 2))
        .cache()

      val cleanCount = cleanSalesDf.count()
      log(f"Valid Clean Transactions Retained: $cleanCount / $rawCount (${cleanCount * 100.0 / rawCount}%.2f%%)")

      // -----------------------------------------------------------------------
      // 3. Total Sales Amount per Transaction
      // -----------------------------------------------------------------------
      log("\n--- 3. Sample Transactions with Calculated Total_Sales (INR) ---")
      log(formatTable(cleanSalesDf.orderBy("Transaction_ID"), 10))
      val totalRevenueRow = cleanSalesDf.agg(
        round(sum("Total_Sales"), 2).as("grand_revenue"),
        sum("Quantity_Sold").as("grand_units"),
        round(avg("Total_Sales"), 2).as("avg_order_value"),
        round(max("Total_Sales"), 2).as("max_order_value")
      ).first()
      val grandRevenue = totalRevenueRow.getAs[Double]("grand_revenue")
      log(f"Grand Total Revenue : INR $grandRevenue%,.2f")
      log(f"Total Units Sold    : ${totalRevenueRow.getAs[Long]("grand_units")}%,d")
      log(f"Average Order Value : INR ${totalRevenueRow.getAs[Double]("avg_order_value")}%,.2f")
      log(f"Max Single Txn Value: INR ${totalRevenueRow.getAs[Double]("max_order_value")}%,.2f")

      // -----------------------------------------------------------------------
      // 4. Category-wise Revenue
      // -----------------------------------------------------------------------
      log("\n--- 4. Total Revenue Generated by Each Product Category ---")
      val categoryRevenueDf = cleanSalesDf
        .groupBy("Category")
        .agg(
          count("*").as("Transactions"),
          sum("Quantity_Sold").as("Total_Units"),
          round(sum("Total_Sales"), 2).as("Total_Revenue_INR"),
          round(avg("Total_Sales"), 2).as("Avg_Transaction_INR")
        )
        .withColumn("Revenue_Share_Percent", round(col("Total_Revenue_INR") * 100.0 / lit(grandRevenue), 2))
        .orderBy(desc("Total_Revenue_INR"))

      log(formatTable(categoryRevenueDf, 20))
      exportDfToCsv(categoryRevenueDf, outputsDir.resolve("category_revenue.csv"))

      // -----------------------------------------------------------------------
      // 5. Top 5 Best-Selling Products (by Revenue AND by Units Sold)
      // -----------------------------------------------------------------------
      log("\n--- 5a. Top 5 Best-Selling Products by Total Revenue ---")
      val productAggDf = cleanSalesDf
        .groupBy("Product_Name", "Category")
        .agg(
          count("*").as("Transactions"),
          sum("Quantity_Sold").as("Total_Units_Sold"),
          round(sum("Total_Sales"), 2).as("Total_Revenue_INR"),
          round(avg("Unit_Price"), 2).as("Avg_Unit_Price_INR")
        )

      val top5ByRevenueDf = productAggDf.orderBy(desc("Total_Revenue_INR")).limit(5)
      log(formatTable(top5ByRevenueDf, 5))
      exportDfToCsv(top5ByRevenueDf, outputsDir.resolve("top5_products_by_revenue.csv"))

      log("--- 5b. Top 5 Best-Selling Products by Quantity Sold ---")
      val top5ByQtyDf = productAggDf.orderBy(desc("Total_Units_Sold")).limit(5)
      log(formatTable(top5ByQtyDf, 5))
      exportDfToCsv(top5ByQtyDf, outputsDir.resolve("top5_products_by_quantity.csv"))

      // Export all products ranking as well
      exportDfToCsv(productAggDf.orderBy(desc("Total_Revenue_INR")), outputsDir.resolve("all_products_summary.csv"))

      // -----------------------------------------------------------------------
      // 6. Location-wise Revenue
      // -----------------------------------------------------------------------
      log("\n--- 6. Location-wise Revenue Breakdown ---")
      val locationRevenueDf = cleanSalesDf
        .groupBy("Store_Location")
        .agg(
          count("*").as("Transactions"),
          sum("Quantity_Sold").as("Total_Units"),
          round(sum("Total_Sales"), 2).as("Total_Revenue_INR"),
          round(avg("Total_Sales"), 2).as("Avg_Transaction_INR")
        )
        .withColumn("Revenue_Share_Percent", round(col("Total_Revenue_INR") * 100.0 / lit(grandRevenue), 2))
        .orderBy(desc("Total_Revenue_INR"))

      log(formatTable(locationRevenueDf, 20))
      exportDfToCsv(locationRevenueDf, outputsDir.resolve("location_revenue.csv"))

      // -----------------------------------------------------------------------
      // 7. Filter Transactions Exceeding INR 10,000
      // -----------------------------------------------------------------------
      log("\n--- 7. High-Value Transactions Exceeding INR 10,000 ---")
      val highValueDf = cleanSalesDf
        .filter(col("Total_Sales") > 10000.0)
        .orderBy(desc("Total_Sales"))

      val highValueRows = exportDfToCsv(highValueDf, outputsDir.resolve("high_value_transactions_gt10000.csv"))
      val highValuePct = (highValueRows.length.toDouble / cleanCount) * 100.0
      log(f"Transactions > INR 10,000: ${highValueRows.length} / $cleanCount ($highValuePct%.2f%%)")
      log("Top 10 Highest-Value Transactions:")
      log(formatTable(highValueDf, 10))

      // -----------------------------------------------------------------------
      // 8. Additional BI Aggregations: Monthly Revenue Trend & Category x Location
      // -----------------------------------------------------------------------
      val monthlyTrendDf = cleanSalesDf
        .withColumn("Year_Month", date_format(col("Transaction_Date"), "yyyy-MM"))
        .groupBy("Year_Month")
        .agg(
          count("*").as("Transactions"),
          sum("Quantity_Sold").as("Total_Units"),
          round(sum("Total_Sales"), 2).as("Total_Revenue_INR")
        )
        .orderBy("Year_Month")
      exportDfToCsv(monthlyTrendDf, outputsDir.resolve("monthly_revenue_trend.csv"))

      val catLocDf = cleanSalesDf
        .groupBy("Store_Location", "Category")
        .agg(round(sum("Total_Sales"), 2).as("Total_Revenue_INR"))
        .orderBy("Store_Location", "Category")
      exportDfToCsv(catLocDf, outputsDir.resolve("category_location_revenue.csv"))

      // -----------------------------------------------------------------------
      // 9. Lazy Evaluation & Catalyst Optimizer Plan Inspection
      // -----------------------------------------------------------------------
      log("\n--- 9. Lazy Evaluation & Catalyst Optimizer Execution Plans ---")
      val jobsBefore = jobCounter.get()
      val tLazy0 = System.nanoTime()

      val catalystQueryDf = spark.read
        .option("header", "true")
        .schema(salesSchema)
        .csv(inputPath.toString)
        .filter(col("Quantity_Sold").isNotNull && col("Unit_Price").isNotNull &&
                col("Quantity_Sold") > 0 && col("Unit_Price") > 0)
        .withColumn("Total_Sales", col("Quantity_Sold") * col("Unit_Price"))
        .filter(col("Total_Sales") > 10000.0)
        .groupBy("Category")
        .agg(
          count("*").as("High_Value_Txns"),
          round(sum("Total_Sales"), 2).as("High_Value_Revenue")
        )
        .orderBy(desc("High_Value_Revenue"))

      val lazyBuildMs = (System.nanoTime() - tLazy0) / 1e6
      val jobsAfterBuild = jobCounter.get()
      log(f"Built multi-stage DataFrame query plan in $lazyBuildMs%.3f ms | Spark Jobs Triggered: ${jobsAfterBuild - jobsBefore}")

      // Capture full Catalyst query execution plans (Parsed, Analyzed, Optimized, Physical)
      val planText = catalystQueryDf.queryExecution.toString()
      writeTextFile(outputsDir.resolve("catalyst_execution_plans.txt"), planText)
      log("Saved full Catalyst Execution Plans (Parsed -> Analyzed -> Optimized -> Physical) to outputs/catalyst_execution_plans.txt")
      log("\nPhysical Plan Preview:")
      log(catalystQueryDf.queryExecution.executedPlan.toString())

      val tExec0 = System.nanoTime()
      val catalystRows = catalystQueryDf.collect()
      val execMs = (System.nanoTime() - tExec0) / 1e6
      val jobsAfterExec = jobCounter.get()
      log(f"\nTriggered action .collect() in $execMs%.2f ms | Spark Jobs Triggered: ${jobsAfterExec - jobsAfterBuild}")
      catalystRows.foreach(r => log(f"  ${r.getString(0)}%-15s | Txns: ${r.getLong(1)}%5d | Revenue: INR ${r.getDouble(2)}%,.2f"))

      // -----------------------------------------------------------------------
      // 10. Empirical Comparison: RDD vs DataFrame Aggregation Benchmark
      // -----------------------------------------------------------------------
      log("\n--- 10. Empirical Performance Benchmark: RDD vs DataFrame (Category Revenue) ---")
      // Warm-up pass
      val _ = spark.read.option("header", "true").schema(salesSchema).csv(inputPath.toString).count()

      // Approach A: Low-level RDD text parsing + filter + reduceByKey
      val rddStart = System.nanoTime()
      val rddResult = sc.textFile(inputPath.toString)
        .filter(line => !line.startsWith("Transaction_ID") && line.trim.nonEmpty)
        .flatMap { line =>
          val p = line.split(",", -1)
          if (p.length >= 6 && p(4).trim.nonEmpty && p(5).trim.nonEmpty) {
            try {
              val qty = p(4).trim.toDouble
              val price = p(5).trim.toDouble
              if (qty > 0 && price > 0) Some((p(2).trim, (qty * price, 1L))) else None
            } catch { case _: NumberFormatException => None }
          } else None
        }
        .reduceByKey { case ((s1, c1), (s2, c2)) => (s1 + s2, c1 + c2) }
        .collect()
        .sortBy(-_._2._1)
      val rddMs = (System.nanoTime() - rddStart) / 1e6

      // Approach B: DataFrame with Catalyst Optimizer + Column Pruning + Tungsten
      val dfStart = System.nanoTime()
      val dfResult = spark.read
        .option("header", "true")
        .schema(salesSchema)
        .csv(inputPath.toString)
        .select("Category", "Quantity_Sold", "Unit_Price") // Column pruning
        .filter(col("Quantity_Sold") > 0 && col("Unit_Price") > 0)
        .groupBy("Category")
        .agg(
          sum(col("Quantity_Sold") * col("Unit_Price")).as("rev"),
          count("*").as("cnt")
        )
        .orderBy(desc("rev"))
        .collect()
      val dfMs = (System.nanoTime() - dfStart) / 1e6

      // Approach C & D: Cached In-Memory Iterative Aggregation (5 runs: JVM Objects RDD vs Tungsten Columnar DataFrame)
      val cachedSalesRdd = cleanSalesDf.rdd.map(r => (r.getString(2), r.getDouble(7))).cache()
      cachedSalesRdd.count() // materialize RDD cache
      cleanSalesDf.count()   // ensure DataFrame InMemoryTableScan cache is warm

      val cachedRddStart = System.nanoTime()
      for (_ <- 1 to 5) {
        cachedSalesRdd
          .mapValues(v => (v, 1L))
          .reduceByKey { case ((s1, c1), (s2, c2)) => (s1 + s2, c1 + c2) }
          .collect()
      }
      val cachedRddMs = (System.nanoTime() - cachedRddStart) / 1e6

      val cachedDfStart = System.nanoTime()
      for (_ <- 1 to 5) {
        cleanSalesDf
          .groupBy("Category")
          .agg(sum("Total_Sales"), count("*"))
          .collect()
      }
      val cachedDfMs = (System.nanoTime() - cachedDfStart) / 1e6

      log(f"  Cold CSV   - RDD Execution Time      : $rddMs%.2f ms (Categories: ${rddResult.length})")
      log(f"  Cold CSV   - DataFrame Execution Time: $dfMs%.2f ms (Categories: ${dfResult.length})")
      log(f"  Cached 5x  - RDD Execution Time      : $cachedRddMs%.2f ms")
      log(f"  Cached 5x  - DataFrame Execution Time: $cachedDfMs%.2f ms")
      val benchmarkCsv =
        s"""Mode,Engine,Operation,Execution_Time_ms,Categories_Returned,Optimization_Layer
           |Cold CSV Read,Spark RDD,textFile + flatMap + reduceByKey,${f"$rddMs%.2f"},${rddResult.length},None (Opaque JVM Lambda Objects)
           |Cold CSV Read,Spark DataFrame,CSV + Column Pruning + HashAggregate,${f"$dfMs%.2f"},${dfResult.length},Catalyst Optimizer + Tungsten Binary + Whole-Stage Codegen
           |Cached In-Memory (5x),Spark RDD,mapValues + reduceByKey (JVM Heap),${f"$cachedRddMs%.2f"},${rddResult.length},Deserialized JVM Tuple Objects
           |Cached In-Memory (5x),Spark DataFrame,groupBy + HashAggregate (InMemoryTableScan),${f"$cachedDfMs%.2f"},${dfResult.length},Catalyst + Tungsten Columnar Compression + Codegen
           |""".stripMargin
      writeTextFile(outputsDir.resolve("rdd_vs_dataframe_benchmark.csv"), benchmarkCsv)

      // Capture Spark UI REST API metadata
      sc.uiWebUrl.foreach { uiUrl =>
        try {
          val appId = sc.applicationId
          writeTextFile(outputsDir.resolve("spark_ui_jobs.json"),
            scala.io.Source.fromURL(s"$uiUrl/api/v1/applications/$appId/jobs").mkString)
          writeTextFile(outputsDir.resolve("spark_ui_stages.json"),
            scala.io.Source.fromURL(s"$uiUrl/api/v1/applications/$appId/stages").mkString)
          writeTextFile(outputsDir.resolve("spark_ui_sql.json"),
            scala.io.Source.fromURL(s"$uiUrl/api/v1/applications/$appId/sql").mkString)
          log("\nCaptured Spark UI REST API JSON (jobs, stages, sql) to outputs/spark_ui_*.json")
        } catch {
          case e: Exception => log(s"Note: Could not fetch Spark UI JSON: ${e.getMessage}")
        }
      }

      writeTextFile(outputsDir.resolve("execution_report.txt"), report.toString())
      log(s"\nAll outputs written to: $outputsDir")

      if (holdUiSeconds > 0) {
        println(s"\n[Spark UI Hold] Keeping Spark UI alive at ${sc.uiWebUrl.getOrElse("")} for $holdUiSeconds seconds...")
        Thread.sleep(holdUiSeconds * 1000L)
      }
    } finally {
      spark.stop()
    }
  }
}
