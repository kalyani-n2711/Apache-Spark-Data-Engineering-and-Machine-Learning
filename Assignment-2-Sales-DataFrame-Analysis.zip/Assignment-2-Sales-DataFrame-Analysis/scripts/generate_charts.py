import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches

plt.rcParams.update({
    "figure.dpi": 160,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
})

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE_DIR, "outputs")
CHART_DIR = os.path.join(OUT_DIR, "charts")
os.makedirs(CHART_DIR, exist_ok=True)

cat_df = pd.read_csv(os.path.join(OUT_DIR, "category_revenue.csv"))
loc_df = pd.read_csv(os.path.join(OUT_DIR, "location_revenue.csv"))
top_rev_df = pd.read_csv(os.path.join(OUT_DIR, "top5_products_by_revenue.csv"))
top_qty_df = pd.read_csv(os.path.join(OUT_DIR, "top5_products_by_quantity.csv"))
monthly_df = pd.read_csv(os.path.join(OUT_DIR, "monthly_revenue_trend.csv"))
bench_df = pd.read_csv(os.path.join(OUT_DIR, "rdd_vs_dataframe_benchmark.csv"))

# 1. Category & Location Revenue
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.5, 5.2))
cat_s = cat_df.sort_values("Total_Revenue_INR", ascending=True)
rev_cr = cat_s["Total_Revenue_INR"] / 1e7
ax1.barh(cat_s["Category"], rev_cr, color="#2b6cb0", height=0.58)
for idx, (val, share) in enumerate(zip(rev_cr, cat_s["Revenue_Share_Percent"])):
    ax1.text(val + 0.08, idx, f"INR {val:.2f} Cr ({share:.1f}%)", va="center", fontsize=8.8)
ax1.set_xlim(0, rev_cr.max() * 1.38)
ax1.set_title("Revenue by Product Category (INR Crore)", fontweight="bold", pad=10)
ax1.set_xlabel("Total Revenue (INR Crore = 10M)")

loc_s = loc_df.sort_values("Total_Revenue_INR", ascending=True)
loc_cr = loc_s["Total_Revenue_INR"] / 1e7
ax2.barh(loc_s["Store_Location"], loc_cr, color="#319795", height=0.6)
for idx, (val, share) in enumerate(zip(loc_cr, loc_s["Revenue_Share_Percent"])):
    ax2.text(val + 0.02, idx, f"INR {val:.2f} Cr ({share:.1f}%)", va="center", fontsize=8.5)
ax2.set_xlim(0, loc_cr.max() * 1.32)
ax2.set_title("Revenue by Store Location (8 Cities)", fontweight="bold", pad=10)
ax2.set_xlabel("Total Revenue (INR Crore = 10M)")

fig.suptitle("Assignment 2 (Spark DataFrames): Category & Regional Sales Revenue", fontsize=13, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "01_category_and_location_revenue.png"), bbox_inches="tight")
plt.close()

# 2. Top 5 Products (Revenue & Quantity) + Monthly Revenue Trend
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(16, 4.9))
tr = top_rev_df.sort_values("Total_Revenue_INR", ascending=True)
ax1.barh(tr["Product_Name"], tr["Total_Revenue_INR"] / 1e5, color="#805ad5", height=0.55)
for idx, val in enumerate(tr["Total_Revenue_INR"] / 1e5):
    ax1.text(val + 1.2, idx, f"{val:.1f}L", va="center", fontsize=8.5)
ax1.set_xlim(0, (tr["Total_Revenue_INR"] / 1e5).max() * 1.22)
ax1.set_title("Top 5 Products by Revenue (INR Lakhs)", fontweight="bold")
ax1.set_xlabel("Revenue (INR Lakhs)")

tq = top_qty_df.sort_values("Total_Units_Sold", ascending=True)
ax2.barh(tq["Product_Name"], tq["Total_Units_Sold"], color="#dd6b20", height=0.55)
for idx, val in enumerate(tq["Total_Units_Sold"]):
    ax2.text(val + 40, idx, f"{int(val):,}", va="center", fontsize=8.5)
ax2.set_xlim(0, tq["Total_Units_Sold"].max() * 1.2)
ax2.set_title("Top 5 Products by Units Sold", fontweight="bold")
ax2.set_xlabel("Units Sold")

ax3.plot(range(len(monthly_df)), monthly_df["Total_Revenue_INR"] / 1e5, marker="o", linewidth=2, color="#2b6cb0", markersize=4.5)
step = max(1, len(monthly_df) // 6)
ax3.set_xticks(range(0, len(monthly_df), step))
ax3.set_xticklabels(monthly_df["Year_Month"].iloc[::step], rotation=35, ha="right", fontsize=8)
ax3.set_title("Monthly Revenue Trend (INR Lakhs)", fontweight="bold")
ax3.set_ylabel("Monthly Revenue (INR Lakhs)")
ax3.grid(axis="y", linestyle="--", alpha=0.35)

fig.suptitle("Assignment 2 (Spark DataFrames): Top Products & Monthly Sales Trajectory", fontsize=13, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "02_top5_products_and_monthly_trend.png"), bbox_inches="tight")
plt.close()

# 3. RDD vs DataFrame Benchmark & Catalyst Optimizer Pipeline
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.2), gridspec_kw={"width_ratios": [1.0, 1.35]})
modes = bench_df["Mode"].unique()
x = range(len(modes))
width = 0.35
rdd_vals = [bench_df[(bench_df["Mode"] == m) & (bench_df["Engine"] == "Spark RDD")]["Execution_Time_ms"].values[0] for m in modes]
df_vals = [bench_df[(bench_df["Mode"] == m) & (bench_df["Engine"] == "Spark DataFrame")]["Execution_Time_ms"].values[0] for m in modes]

bars1 = ax1.bar([i - width / 2 for i in x], rdd_vals, width, label="Spark RDD", color="#e53e3e", alpha=0.85)
bars2 = ax1.bar([i + width / 2 for i in x], df_vals, width, label="Spark DataFrame", color="#2b6cb0", alpha=0.9)
for b in list(bars1) + list(bars2):
    ax1.text(b.get_x() + b.get_width() / 2, b.get_height() + 8, f"{b.get_height():.1f} ms", ha="center", fontsize=8.5, fontweight="bold")
ax1.set_xticks(list(x))
ax1.set_xticklabels(modes, fontsize=9)
ax1.set_ylim(0, max(rdd_vals + df_vals) * 1.2)
ax1.set_ylabel("Execution Time (ms)")
ax1.set_title("Empirical Runtime: Spark RDD vs DataFrame", fontweight="bold")
ax1.legend(frameon=False)

ax2.set_xlim(0, 10)
ax2.set_ylim(0, 7)
ax2.axis("off")
ax2.set_title("Catalyst Optimizer & Tungsten Execution Pipeline", fontweight="bold")
stages = [
    (0.5, 5.5, 9.0, 0.95, "#edf2f7", "#4a5568", "1. Unresolved Logical Plan (DataFrame API: filter -> withColumn -> groupBy)"),
    (0.5, 4.15, 9.0, 0.95, "#ebf8ff", "#3182ce", "2. Analyzed Logical Plan (Catalog resolves columns & types via StructType)"),
    (0.5, 2.8, 9.0, 0.95, "#e6fffa", "#319795", "3. Optimized Logical Plan (Predicate Pushdown + Column Pruning: reads 3 of 7 cols)"),
    (0.5, 1.45, 9.0, 0.95, "#f0fff4", "#38a169", "4. Physical Plan + Tungsten (Partial HashAggregate -> Exchange -> Final HashAggregate)"),
    (0.5, 0.15, 9.0, 0.95, "#faf5ff", "#805ad5", "5. Whole-Stage Codegen (Fused JVM bytecode on off-heap binary UnsafeRow memory)"),
]
for x0, y0, w, h, fc, ec, txt in stages:
    box = patches.FancyBboxPatch((x0, y0), w, h, boxstyle="round,pad=0.06", facecolor=fc, edgecolor=ec, linewidth=1.4)
    ax2.add_patch(box)
    ax2.text(x0 + w / 2, y0 + h / 2, txt, ha="center", va="center", fontsize=8.6, fontweight="bold", color="#1a202c")
for y_top, y_bot in [(5.45, 5.15), (4.10, 3.80), (2.75, 2.45), (1.40, 1.15)]:
    ax2.annotate("", xy=(5.0, y_bot), xytext=(5.0, y_top), arrowprops=dict(arrowstyle="->", lw=1.6, color="#2d3748"))

plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "03_rdd_vs_dataframe_benchmark_and_catalyst.png"), bbox_inches="tight")
plt.close()
print("Generated SalesDataFrameAnalysis charts successfully.")
