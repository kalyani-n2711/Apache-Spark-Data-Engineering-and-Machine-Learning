$ErrorActionPreference = "Stop"
if (-not $env:JAVA_HOME -or -not (Test-Path "$env:JAVA_HOME\bin\java.exe")) {
    $env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
}
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"

if (Get-Command scala-cli -ErrorAction SilentlyContinue) {
    scala-cli run --server=false src/main/scala/edu/university/mllib/DiabetesPredictionPipeline.scala -- @args
} else {
    mvn compile exec:java
}
