import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams.update({
    "figure.dpi": 160,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
})

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE_DIR, "outputs")
CHART_DIR = os.path.join(OUT_DIR, "charts")
os.makedirs(CHART_DIR, exist_ok=True)

audit_df = pd.read_csv(os.path.join(OUT_DIR, "data_quality_audit.csv"))
comp_df = pd.read_csv(os.path.join(OUT_DIR, "model_comparison.csv"))
fi_df = pd.read_csv(os.path.join(OUT_DIR, "feature_importances.csv"))
pred_df = pd.read_csv(os.path.join(OUT_DIR, "new_patient_predictions.csv"))
raw_df = pd.read_csv(os.path.join(BASE_DIR, "data", "synthetic_diabetes_prediction_10000.csv"))

# 1. Data Quality Audit & Class Imbalance
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 4.8))
invalid_df = audit_df[audit_df["Biologically_Invalid_Zeros"] > 0].sort_values("Biologically_Invalid_Zeros", ascending=True)
ax1.barh(invalid_df["Column"], invalid_df["Biologically_Invalid_Zeros"], color="#dd6b20", height=0.55)
for idx, val in enumerate(invalid_df["Biologically_Invalid_Zeros"]):
    ax1.text(val + 25, idx, f"{int(val):,} ({val/100:.2f}%)", va="center", fontsize=9)
ax1.set_xlim(0, invalid_df["Biologically_Invalid_Zeros"].max() * 1.28)
ax1.set_title("Biologically Invalid Zero Values Imputed", fontweight="bold")
ax1.set_xlabel("Zero-Value Count (out of 10,000)")

cls_counts = raw_df["Outcome"].value_counts().sort_index()
labels = ["Outcome = 0\n(Non-Diabetic)", "Outcome = 1\n(Diabetic)"]
bars = ax2.bar(labels, cls_counts.values, color=["#3182ce", "#e53e3e"], width=0.5)
for b in bars:
    pct = b.get_height() / len(raw_df) * 100
    ax2.text(b.get_x() + b.get_width() / 2, b.get_height() + 180, f"{int(b.get_height()):,}\n({pct:.2f}%)",
             ha="center", fontsize=9.5, fontweight="bold")
ax2.set_ylim(0, cls_counts.max() * 1.18)
ax2.set_title("Severe Class Imbalance (Handled via Balanced classWeight)", fontweight="bold")
ax2.set_ylabel("Patient Count")

fig.suptitle("Assignment 3 (Spark MLlib): Preprocessing & Class Distribution", fontsize=13, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "01_data_quality_and_class_imbalance.png"), bbox_inches="tight")
plt.close()

# 2. Model Performance Metrics & Confusion Matrices
fig = plt.figure(figsize=(14, 8.2))
gs = fig.add_gridspec(2, 3, height_ratios=[1.15, 1.0])

ax_top = fig.add_subplot(gs[0, :])
metrics = ["Accuracy", "Weighted_F1", "ROC_AUC", "Positive_Recall"]
metric_labels = ["Accuracy", "Weighted F1", "ROC-AUC", "Positive Recall (Sensitivity)"]
x = np.arange(len(comp_df))
width = 0.19
colors = ["#2b6cb0", "#38a169", "#805ad5", "#dd6b20"]
for i, (m, lbl, col) in enumerate(zip(metrics, metric_labels, colors)):
    vals = comp_df[m].values
    bars = ax_top.bar(x + (i - 1.5) * width, vals, width, label=lbl, color=col, alpha=0.9)
    for b in bars:
        ax_top.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.015, f"{b.get_height():.3f}",
                    ha="center", fontsize=8, fontweight="bold")
ax_top.set_xticks(x)
ax_top.set_xticklabels(comp_df["Model"], fontsize=10.5, fontweight="bold")
ax_top.set_ylim(0, 1.08)
ax_top.set_ylabel("Score")
ax_top.set_title("MLlib Classifier Evaluation Metrics on Stratified Test Set (N = 1,916)", fontweight="bold", pad=8)
ax_top.legend(loc="upper right", ncol=4, frameon=False)

for idx, row in enumerate(comp_df.itertuples()):
    ax_cm = fig.add_subplot(gs[1, idx])
    cm = np.array([[row.TN, row.FP], [row.FN, row.TP]])
    ax_cm.imshow(cm, cmap="Blues", aspect="auto")
    cell_labels = [[f"TN\n{row.TN}", f"FP\n{row.FP}"], [f"FN\n{row.FN}", f"TP\n{row.TP}"]]
    thresh = cm.max() / 2.0
    for r in range(2):
        for c in range(2):
            ax_cm.text(c, r, cell_labels[r][c], ha="center", va="center", fontsize=10, fontweight="bold",
                       color="white" if cm[r, c] > thresh else "#1a202c")
    ax_cm.set_xticks([0, 1])
    ax_cm.set_xticklabels(["Pred 0", "Pred 1"])
    ax_cm.set_yticks([0, 1])
    ax_cm.set_yticklabels(["Actual 0", "Actual 1"])
    ax_cm.set_title(f"{row.Model}\n(ROC-AUC: {row.ROC_AUC:.4f})", fontweight="bold", fontsize=10)

plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "02_model_performance_and_confusion_matrices.png"), bbox_inches="tight")
plt.close()

# 3. Feature Importances & New Patient Predictions
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.5, 5.2))
fi_s = fi_df.sort_values("RF_Importance", ascending=True)
y = np.arange(len(fi_s))
h = 0.36
ax1.barh(y - h / 2, fi_s["RF_Importance"], h, label="Random Forest Importance", color="#2b6cb0")
ax1.barh(y + h / 2, fi_s["DT_Importance"], h, label="Decision Tree Importance", color="#38a169")
ax1.set_yticks(y)
ax1.set_yticklabels(fi_s["Feature"])
ax1.set_xlabel("Gini Feature Importance")
ax1.set_title("Tree-Based Feature Importances (Glucose #1)", fontweight="bold")
ax1.legend(frameon=False, loc="lower right")

p_labels = [f"Patient {int(r.Patient_No)}\n(Gluc={r.Glucose:.0f}, BMI={r.BMI:.1f})" for r in pred_df.itertuples()]
probs = pred_df["Prob_Diabetic"].values * 100
p_colors = ["#e53e3e" if p >= 50 else "#3182ce" for p in probs]
bars = ax2.barh(p_labels, probs, color=p_colors, height=0.55)
ax2.axvline(50.0, color="#2d3748", linestyle="--", linewidth=1.4, label="50% Classification Threshold")
for idx, val in enumerate(probs):
    ax2.text(val + 1.5, idx, f"{val:.1f}%", va="center", fontsize=9, fontweight="bold")
ax2.set_xlim(0, 108)
ax2.set_xlabel("Predicted Probability of Diabetes (%)")
ax2.set_title("New Patient Risk Predictions (Best Model: Logistic Regression)", fontweight="bold")
ax2.legend(loc="lower right", frameon=False)

fig.suptitle("Assignment 3 (Spark MLlib): Clinical Feature Drivers & Unseen Patient Inference", fontsize=13, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "03_feature_importances_and_patient_predictions.png"), bbox_inches="tight")
plt.close()
print("Generated DiabetesMLlibPipeline charts successfully.")
