# Assignment 3: Healthcare Disease Prediction Using Apache Spark MLlib

## 1. Overview & Scenario
A healthcare organization wants a scalable classification pipeline to predict diabetes status (`Outcome = 0` or `1`) from 8 clinical attributes (`Pregnancies`, `Glucose`, `BloodPressure`, `SkinThickness`, `Insulin`, `BMI`, `DiabetesPedigreeFunction`, `Age`). This project implements an end-to-end, leak-free **Apache Spark MLlib 3.5.3** pipeline in **Scala 2.12.18**.

> **Dataset Note:** `data/synthetic_diabetes_prediction_10000.csv` is a **synthetic** 10,000-row clinical dataset modeled after the Pima Indians Diabetes schema.

---

## 2. Project Structure

```text
Assignment-3-Healthcare-MLlib-Prediction/
├── data/
│   └── synthetic_diabetes_prediction_10000.csv
├── project/build.properties
├── scripts/generate_charts.py
├── src/main/scala/edu/university/mllib/
│   └── DiabetesPredictionPipeline.scala    # MLlib Pipeline, 3 Classifiers & Inference
├── build.sbt
├── pom.xml
├── run.ps1
└── README.md
```

---

## 3. Data Preprocessing, Imbalance Handling & MLlib Pipeline

### 3.1 Biologically Invalid Zero Audit
Although there are `0` explicit SQL `null` entries, five clinical measurements contain biologically impossible `0.0` placeholders:
- `Insulin`: **1,800** invalid zeros (`18.00%`)
- `SkinThickness`: **500** invalid zeros (`5.00%`)
- `BMI`: **55** invalid zeros (`0.55%`)
- `BloodPressure`: **45** invalid zeros (`0.45%`)
- `Glucose`: **35** invalid zeros (`0.35%`)
*(Note: `Pregnancies == 0` is clinically valid.)*

All invalid `0.0` values in those 5 columns are converted to `null` before splitting so `Imputer(strategy = "median")` learns medians strictly from the training split without data leakage.

### 3.2 Stratified Split & Class Imbalance
- **Class Distribution:** `Outcome = 0` (Non-Diabetic): `9,832` (`98.32%`) vs. `Outcome = 1` (Diabetic): `168` (`1.68%`).
- **Stratified 80/20 Split:** Training = `8,084` (`141` positive, `7,943` negative); Test = `1,916` (`27` positive, `1,889` negative).
- **Balanced `classWeight`:** Inverse-frequency training weights (`Outcome=1 -> 28.6667`, `Outcome=0 -> 0.5089`) prevent models from collapsing to majority-class-only predictions.

### 3.3 4-Stage `org.apache.spark.ml.Pipeline`
1. `Imputer` (`median` strategy for the 5 clinical columns)
2. `VectorAssembler` (combines 8 predictors into `rawFeatures`)
3. `StandardScaler` (`withMean = true, withStd = true` -> `features`)
4. **Classifier (`weightCol = "classWeight"`):** `LogisticRegression`, `DecisionTreeClassifier`, and `RandomForestClassifier`

---

## 4. Model Comparison & Results (Test Set, N = 1,916)

| Model | Accuracy | Weighted Precision | Weighted Recall | Weighted F1 | Positive Precision | Positive Recall | Positive F1 | ROC-AUC | PR-AUC | TP | FP | TN | FN | Train Time (ms) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Logistic Regression** | 0.6733 | 0.9778 | 0.6733 | 0.7921 | 0.0254 | 0.5926 | 0.0486 | **0.6590** | 0.0400 | 16 | 615 | 1,274 | 11 | 8,429.8 |
| **Decision Tree** | 0.6232 | 0.9779 | 0.6232 | 0.7551 | 0.0233 | **0.6296** | 0.0450 | 0.6480 | 0.0272 | 17 | 712 | 1,177 | 10 | 4,995.2 |
| **Random Forest** | **0.8439** | 0.9754 | **0.8439** | **0.9028** | **0.0310** | 0.3333 | **0.0568** | 0.6419 | **0.0622** | 9 | 281 | 1,608 | 18 | 4,758.0 |

### Interpretation & Best Model Selection
- **Selected Best Model (`ROC-AUC = 0.6590`):** **Logistic Regression** leads in overall probability ranking (`ROC-AUC = 0.6590`) and captures `59.26%` of diabetic cases (`16/27`).
- **Clinical Tradeoff:** **Decision Tree** maximizes screening sensitivity (`62.96%` positive recall), whereas **Random Forest** achieves the highest overall Accuracy (`84.39%`), Weighted F1 (`0.9028`), Positive F1 (`0.0568`), and PR-AUC (`0.0622`) with fewer false alarms (`FP = 281`).
- **Top Feature Drivers:** `Glucose` is the dominant predictor across all three models (`RF = 0.3545`, `DT = 0.4918`, `LR Std Coef = +0.7701`), followed by `BMI` (`RF = 0.1487`, `LR Coef = +0.2712`) and `Pregnancies` (`LR Coef = +0.2552`).

---

## 5. New Patient Record Predictions (Best Model: Logistic Regression)

| Patient | Pregnancies | Glucose | BloodPressure | SkinThickness | Insulin | BMI | DPF | Age | Predicted Class | Risk Assessment | P(Diabetic) |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|
| 1 | 1 | 88.0 | 68.0 | 18.0 | 75.0 | 23.4 | 0.240 | 24 | `0` | Non-Diabetic (Low Risk) | 14.61% |
| 2 | 2 | 108.0 | 74.0 | 22.0 | 95.0 | 27.8 | 0.350 | 31 | `0` | Non-Diabetic (Low Risk) | 28.75% |
| 3 | 4 | 146.0 | 82.0 | 31.0 | 185.0 | 34.6 | 0.680 | 44 | `1` | **Diabetic (High Risk)** | **68.38%** |
| 4 | 6 | 178.0 | 88.0 | 35.0 | 240.0 | 39.2 | 0.920 | 52 | `1` | **Diabetic (High Risk)** | **89.60%** |
| 5* | 0 | 128.0 | 72.0 | 0.0* | 0.0* | 31.5 | 0.450 | 36 | `0` | Non-Diabetic (Low Risk) | 39.60% |
| 6 | 5 | 165.0 | 84.0 | 33.0 | 210.0 | 36.8 | 0.810 | 49 | `1` | **Diabetic (High Risk)** | **82.67%** |

*\*Patient 5 demonstrates automatic median imputation of missing (`0.0`) `SkinThickness` and `Insulin` values inside the fitted `PipelineModel`.*

---

## 6. How Spark MLlib Supports Distributed Machine Learning
- **DataFrame-Native Execution:** `spark.ml` leverages Catalyst and Tungsten columnar memory rather than copying data out of the JVM.
- **Distributed Optimization & Tree Training:** Logistic Regression aggregates per-partition gradients via `treeAggregate`, while Decision Tree and Random Forest build distributed feature histograms (`maxBins`) across executor partitions.
- **Serializable Pipelines:** `PipelineModel` packages imputation, scaling, and model weights into one reproducible workflow for distributed batch scoring.

---

## 7. How to Build and Run

```bash
cd Assignment-3-Healthcare-MLlib-Prediction

# Option 1: sbt
sbt run

# Option 2: Apache Maven (Java 17)
mvn compile exec:java

# Option 3: PowerShell + Scala CLI (Windows)
.\run.ps1
```

Pass `--hold-ui 30` to inspect the Spark UI on `http://localhost:4042`. Run `python scripts/generate_charts.py` after execution to generate evaluation and feature-importance plots in `outputs/charts/`.
