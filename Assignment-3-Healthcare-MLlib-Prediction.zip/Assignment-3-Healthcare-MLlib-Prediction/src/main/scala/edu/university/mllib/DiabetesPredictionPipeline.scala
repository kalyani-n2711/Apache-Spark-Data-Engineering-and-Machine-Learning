//> using scala 2.12.18
//> using dep org.apache.spark::spark-core:3.5.3
//> using dep org.apache.spark::spark-sql:3.5.3
//> using dep org.apache.spark::spark-mllib:3.5.3
//> using javaOpt --add-opens=java.base/java.lang=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.lang.invoke=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.lang.reflect=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.io=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.net=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.nio=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util.concurrent=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.nio.ch=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.nio.cs=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.security.action=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.util.calendar=ALL-UNNAMED
//> using javaOpt --add-opens=java.security.jgss/sun.security.krb5=ALL-UNNAMED

package edu.university.mllib

import java.nio.charset.StandardCharsets
import java.nio.file.{Files, Path, Paths}
import org.apache.spark.ml.{Pipeline, PipelineModel, PipelineStage}
import org.apache.spark.ml.classification._
import org.apache.spark.ml.evaluation.{BinaryClassificationEvaluator, MulticlassClassificationEvaluator}
import org.apache.spark.ml.feature.{Imputer, StandardScaler, VectorAssembler}
import org.apache.spark.ml.linalg.Vector
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

/**
 * Assignment 3: Healthcare Disease Prediction Using Apache Spark MLlib
 *
 * Implements:
 *  1. Loading 10,000-row Pima-style synthetic diabetes dataset into Spark DataFrame.
 *  2. Data quality audit (nulls + biologically impossible 0s in clinical features).
 *  3. Leak-free MLlib Pipeline: Imputer (median) -> VectorAssembler -> StandardScaler -> Classifier.
 *  4. Class-balanced training using classWeight column (addressing 98.32% vs 1.68% imbalance)
 *     across Logistic Regression, Decision Tree, and Random Forest classifiers.
 *  5. Evaluation: Accuracy, Weighted & Positive-Class Precision/Recall/F1, ROC-AUC, PR-AUC, Confusion Matrix.
 *  6. Best-model selection + prediction on new unseen patient records.
 */
object DiabetesPredictionPipeline {

  private val ZeroInvalidCols = Seq("Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI")
  private val FeatureCols = Array(
    "Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
    "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"
  )

  private case class EvalResult(
      modelName: String,
      accuracy: Double,
      weightedPrecision: Double,
      weightedRecall: Double,
      weightedF1: Double,
      posPrecision: Double,
      posRecall: Double,
      posF1: Double,
      rocAuc: Double,
      prAuc: Double,
      tp: Long,
      fp: Long,
      tn: Long,
      fn: Long,
      trainTimeMs: Double,
      pipelineModel: PipelineModel
  )

  private def resolveInputPath(cliArg: Option[String]): Path = {
    val candidates = cliArg.toSeq ++ Seq(
      "data/synthetic_diabetes_prediction_10000.csv",
      "Assignment-3-Healthcare-MLlib-Prediction/data/synthetic_diabetes_prediction_10000.csv",
      "synthetic_diabetes_prediction_10000.csv"
    )
    candidates
      .map(p => Paths.get(p).toAbsolutePath.normalize())
      .find(Files.exists(_))
      .getOrElse {
        throw new IllegalArgumentException(
          s"Could not locate data/synthetic_diabetes_prediction_10000.csv. Checked: ${candidates.mkString(", ")}"
        )
      }
  }

  private def writeTextFile(path: Path, content: String): Unit = {
    Files.createDirectories(path.getParent)
    Files.write(path, content.getBytes(StandardCharsets.UTF_8))
  }

  private def formatTable(df: DataFrame, maxRows: Int = 15): String = {
    val cols = df.columns
    val rows = df.take(maxRows).map(r => r.toSeq.map(v => if (v == null) "null" else v.toString))
    val widths = cols.indices.map { i =>
      val dataMax = if (rows.isEmpty) 0 else rows.map(_(i).length).max
      math.min(28, math.max(cols(i).length, dataMax))
    }
    def fmtRow(cells: Seq[String]): String =
      cells.zip(widths).map { case (c, w) =>
        val clipped = if (c.length > w) c.take(w - 3) + "..." else c
        clipped.padTo(w, ' ')
      }.mkString("| ", " | ", " |")
    val sep = widths.map("-" * _).mkString("+-", "-+-", "-+")
    (Seq(sep, fmtRow(cols), sep) ++ rows.map(fmtRow) ++ Seq(sep)).mkString("\n")
  }

  private def buildAndEvaluate(
      modelName: String,
      classifier: PipelineStage,
      trainDf: DataFrame,
      testDf: DataFrame
  ): EvalResult = {
    val imputedCols = ZeroInvalidCols.map(c => s"${c}_imputed").toArray
    val imputer = new Imputer()
      .setInputCols(ZeroInvalidCols.toArray)
      .setOutputCols(imputedCols)
      .setStrategy("median")

    val assembledCols = Array(
      "Pregnancies",
      "Glucose_imputed",
      "BloodPressure_imputed",
      "SkinThickness_imputed",
      "Insulin_imputed",
      "BMI_imputed",
      "DiabetesPedigreeFunction",
      "Age"
    )

    val assembler = new VectorAssembler()
      .setInputCols(assembledCols)
      .setOutputCol("rawFeatures")
      .setHandleInvalid("keep")

    val scaler = new StandardScaler()
      .setInputCol("rawFeatures")
      .setOutputCol("features")
      .setWithMean(true)
      .setWithStd(true)

    val pipeline = new Pipeline().setStages(Array(imputer, assembler, scaler, classifier))

    val t0 = System.nanoTime()
    val model = pipeline.fit(trainDf)
    val trainTimeMs = (System.nanoTime() - t0) / 1e6

    val preds = model.transform(testDf).cache()

    val accEval = new MulticlassClassificationEvaluator().setLabelCol("Outcome").setPredictionCol("prediction")
    val accuracy = accEval.setMetricName("accuracy").evaluate(preds)
    val weightedPrecision = accEval.setMetricName("weightedPrecision").evaluate(preds)
    val weightedRecall = accEval.setMetricName("weightedRecall").evaluate(preds)
    val weightedF1 = accEval.setMetricName("f1").evaluate(preds)

    val binEval = new BinaryClassificationEvaluator().setLabelCol("Outcome").setRawPredictionCol("rawPrediction")
    val rocAuc = binEval.setMetricName("areaUnderROC").evaluate(preds)
    val prAuc = binEval.setMetricName("areaUnderPR").evaluate(preds)

    val cmRow = preds.agg(
      sum(when(col("Outcome") === 1.0 && col("prediction") === 1.0, 1L).otherwise(0L)).as("tp"),
      sum(when(col("Outcome") === 0.0 && col("prediction") === 1.0, 1L).otherwise(0L)).as("fp"),
      sum(when(col("Outcome") === 0.0 && col("prediction") === 0.0, 1L).otherwise(0L)).as("tn"),
      sum(when(col("Outcome") === 1.0 && col("prediction") === 0.0, 1L).otherwise(0L)).as("fn")
    ).first()

    val tp = cmRow.getAs[Long]("tp")
    val fp = cmRow.getAs[Long]("fp")
    val tn = cmRow.getAs[Long]("tn")
    val fn = cmRow.getAs[Long]("fn")

    val posPrecision = if (tp + fp == 0) 0.0 else tp.toDouble / (tp + fp)
    val posRecall = if (tp + fn == 0) 0.0 else tp.toDouble / (tp + fn)
    val posF1 = if (posPrecision + posRecall == 0) 0.0 else 2 * posPrecision * posRecall / (posPrecision + posRecall)

    preds.unpersist()

    EvalResult(
      modelName = modelName,
      accuracy = accuracy,
      weightedPrecision = weightedPrecision,
      weightedRecall = weightedRecall,
      weightedF1 = weightedF1,
      posPrecision = posPrecision,
      posRecall = posRecall,
      posF1 = posF1,
      rocAuc = rocAuc,
      prAuc = prAuc,
      tp = tp, fp = fp, tn = tn, fn = fn,
      trainTimeMs = trainTimeMs,
      pipelineModel = model
    )
  }

  def main(args: Array[String]): Unit = {
    val argList = args.toList
    val csvArg = argList.find(a => !a.startsWith("--"))
    val holdUiSeconds = argList
      .sliding(2)
      .collectFirst { case List("--hold-ui", secs) => secs.toInt }
      .getOrElse(0)

    val inputPath = resolveInputPath(csvArg)
    val projectDir =
      if (inputPath.getParent.getFileName.toString == "data") inputPath.getParent.getParent
      else inputPath.getParent
    val outputsDir = projectDir.resolve("outputs")
    Files.createDirectories(outputsDir)

    val spark = SparkSession.builder()
      .appName("Assignment3-DiabetesPrediction-MLlib")
      .master("local[*]")
      .config("spark.ui.enabled", "true")
      .config("spark.ui.port", "4042")
      .config("spark.sql.shuffle.partitions", "8")
      .getOrCreate()

    val sc = spark.sparkContext
    sc.setLogLevel("WARN")

    val report = new StringBuilder()
    def log(msg: String): Unit = {
      println(msg)
      report.append(msg).append("\n")
    }

    try {
      log("=" * 84)
      log("ASSIGNMENT 3: HEALTHCARE DIABETES PREDICTION USING APACHE SPARK MLLIB")
      log("=" * 84)
      log(s"Spark Version : ${spark.version}")
      log(s"Spark Web UI  : ${sc.uiWebUrl.getOrElse("Disabled")}")
      log(s"Dataset Path  : $inputPath")

      // -----------------------------------------------------------------------
      // 1. Load Dataset with Explicit Schema
      // -----------------------------------------------------------------------
      val schema = StructType(Seq(
        StructField("Pregnancies", DoubleType, nullable = true),
        StructField("Glucose", DoubleType, nullable = true),
        StructField("BloodPressure", DoubleType, nullable = true),
        StructField("SkinThickness", DoubleType, nullable = true),
        StructField("Insulin", DoubleType, nullable = true),
        StructField("BMI", DoubleType, nullable = true),
        StructField("DiabetesPedigreeFunction", DoubleType, nullable = true),
        StructField("Age", DoubleType, nullable = true),
        StructField("Outcome", DoubleType, nullable = true)
      ))

      val rawDf = spark.read
        .option("header", "true")
        .schema(schema)
        .csv(inputPath.toString)
        .cache()

      val totalRows = rawDf.count()
      log(s"\n--- 1. Dataset Loaded (Total Rows: $totalRows, Features: ${FeatureCols.length}, Target: Outcome) ---")
      log(rawDf.schema.treeString)
      log("Sample Records:")
      log(formatTable(rawDf, 6))

      // -----------------------------------------------------------------------
      // 2. Data Preprocessing & Missing / Invalid Value Audit
      // -----------------------------------------------------------------------
      log("\n--- 2. Data Quality Audit (Nulls & Biologically Impossible Zero Values) ---")
      val auditCsvLines = scala.collection.mutable.ArrayBuffer(
        "Column,Null_Count,Zero_Count,Biologically_Invalid_Zeros,Min_Valid,Mean_Raw,Max_Raw"
      )
      for (colName <- rawDf.columns) {
        val statsRow = rawDf.agg(
          sum(when(col(colName).isNull || isnan(col(colName)), 1L).otherwise(0L)).as("nulls"),
          sum(when(col(colName) === 0.0, 1L).otherwise(0L)).as("zeros"),
          min(when(col(colName) > 0.0, col(colName))).as("min_pos"),
          avg(col(colName)).as("mean_val"),
          max(col(colName)).as("max_val")
        ).first()
        val nulls = statsRow.getAs[Long]("nulls")
        val zeros = statsRow.getAs[Long]("zeros")
        val invalidZeros = if (ZeroInvalidCols.contains(colName)) zeros else 0L
        val minPos = Option(statsRow.get(2)).map(_.toString).getOrElse("0.0")
        val meanVal = statsRow.getAs[Double]("mean_val")
        val maxVal = statsRow.getAs[Double]("max_val")
        log(f"  $colName%-26s | Nulls: $nulls%3d | Zeros: $zeros%4d | Invalid Zeros: $invalidZeros%4d | Mean: $meanVal%7.3f | Max: $maxVal%7.3f")
        auditCsvLines += f"$colName,$nulls,$zeros,$invalidZeros,$minPos,$meanVal%.4f,$maxVal%.4f"
      }
      writeTextFile(outputsDir.resolve("data_quality_audit.csv"), auditCsvLines.mkString("\n"))

      val classCounts = rawDf.groupBy("Outcome").count().orderBy("Outcome").collect()
      log("\nTarget Class Distribution (Outcome):")
      classCounts.foreach { r =>
        val cls = r.getDouble(0).toInt
        val cnt = r.getLong(1)
        log(f"  Outcome = $cls (${if (cls == 1) "Diabetic    " else "Non-Diabetic"}) : $cnt%5d (${cnt * 100.0 / totalRows}%5.2f%%)")
      }

      // Replace biologically impossible 0.0 values with null so MLlib Imputer fits median on training set only
      val cleanedForPipelineDf = ZeroInvalidCols.foldLeft(rawDf) { (df, c) =>
        df.withColumn(c, when(col(c) === 0.0, lit(null).cast(DoubleType)).otherwise(col(c)))
      }

      // -----------------------------------------------------------------------
      // 3. Stratified 80/20 Train-Test Split + Class Weight Calculation
      // -----------------------------------------------------------------------
      val posDf = cleanedForPipelineDf.filter(col("Outcome") === 1.0)
      val negDf = cleanedForPipelineDf.filter(col("Outcome") === 0.0)
      val Array(posTrain, posTest) = posDf.randomSplit(Array(0.8, 0.2), seed = 42L)
      val Array(negTrain, negTest) = negDf.randomSplit(Array(0.8, 0.2), seed = 42L)

      val rawTrainDf = posTrain.union(negTrain)
      val testDf = posTest.union(negTest).cache()

      val trainTotal = rawTrainDf.count()
      val trainPos = rawTrainDf.filter(col("Outcome") === 1.0).count()
      val trainNeg = trainTotal - trainPos
      val posWeight = trainTotal.toDouble / (2.0 * trainPos)
      val negWeight = trainTotal.toDouble / (2.0 * trainNeg)

      val trainDf = rawTrainDf
        .withColumn("classWeight", when(col("Outcome") === 1.0, lit(posWeight)).otherwise(lit(negWeight)))
        .cache()

      val testTotal = testDf.count()
      val testPos = testDf.filter(col("Outcome") === 1.0).count()
      log(s"\n--- 3. Stratified 80/20 Split & Class-Balanced Weights ---")
      log(f"  Training Set : $trainTotal rows (Positive: $trainPos, Negative: $trainNeg)")
      log(f"  Testing Set  : $testTotal rows (Positive: $testPos, Negative: ${testTotal - testPos})")
      log(f"  Class Weights: Outcome=1 -> $posWeight%.4f | Outcome=0 -> $negWeight%.4f")

      // -----------------------------------------------------------------------
      // 4. Build MLlib Pipelines & Train 3 Classifiers
      // -----------------------------------------------------------------------
      log("\n--- 4. Training MLlib Pipelines (Imputer -> VectorAssembler -> StandardScaler -> Classifier) ---")

      val lr = new LogisticRegression()
        .setFeaturesCol("features")
        .setLabelCol("Outcome")
        .setWeightCol("classWeight")
        .setMaxIter(100)
        .setRegParam(0.01)

      val dt = new DecisionTreeClassifier()
        .setFeaturesCol("features")
        .setLabelCol("Outcome")
        .setWeightCol("classWeight")
        .setMaxDepth(5)
        .setMinInstancesPerNode(15)
        .setSeed(42L)

      val rf = new RandomForestClassifier()
        .setFeaturesCol("features")
        .setLabelCol("Outcome")
        .setWeightCol("classWeight")
        .setNumTrees(60)
        .setMaxDepth(6)
        .setMinInstancesPerNode(10)
        .setSeed(42L)

      val results = Seq(
        buildAndEvaluate("Logistic Regression", lr, trainDf, testDf),
        buildAndEvaluate("Decision Tree", dt, trainDf, testDf),
        buildAndEvaluate("Random Forest", rf, trainDf, testDf)
      )

      // -----------------------------------------------------------------------
      // 5. Performance Comparison Table
      // -----------------------------------------------------------------------
      log("\n--- 5. Model Performance Comparison Table (Test Set) ---")
      log(f"  ${"Model"}%-20s | ${"Acc"}%6s | ${"W-Prec"}%6s | ${"W-Rec"}%6s | ${"W-F1"}%6s | ${"Pos-Prec"}%8s | ${"Pos-Rec"}%7s | ${"Pos-F1"}%6s | ${"ROC-AUC"}%7s | ${"PR-AUC"}%6s")
      log("  " + "-" * 106)
      val compCsv = scala.collection.mutable.ArrayBuffer(
        "Model,Accuracy,Weighted_Precision,Weighted_Recall,Weighted_F1,Positive_Precision,Positive_Recall,Positive_F1,ROC_AUC,PR_AUC,TP,FP,TN,FN,Train_Time_ms"
      )
      val cmCsv = scala.collection.mutable.ArrayBuffer("Model,TP,FP,TN,FN")

      results.foreach { r =>
        log(f"  ${r.modelName}%-20s | ${r.accuracy}%6.4f | ${r.weightedPrecision}%6.4f | ${r.weightedRecall}%6.4f | ${r.weightedF1}%6.4f | ${r.posPrecision}%8.4f | ${r.posRecall}%7.4f | ${r.posF1}%6.4f | ${r.rocAuc}%7.4f | ${r.prAuc}%6.4f")
        log(f"    -> Confusion Matrix: TP=${r.tp}, FP=${r.fp}, TN=${r.tn}, FN=${r.fn} (Train time: ${r.trainTimeMs}%.1f ms)")
        compCsv += f"${r.modelName},${r.accuracy}%.4f,${r.weightedPrecision}%.4f,${r.weightedRecall}%.4f,${r.weightedF1}%.4f,${r.posPrecision}%.4f,${r.posRecall}%.4f,${r.posF1}%.4f,${r.rocAuc}%.4f,${r.prAuc}%.4f,${r.tp},${r.fp},${r.tn},${r.fn},${r.trainTimeMs}%.2f"
        cmCsv += s"${r.modelName},${r.tp},${r.fp},${r.tn},${r.fn}"
      }
      writeTextFile(outputsDir.resolve("model_comparison.csv"), compCsv.mkString("\n"))
      writeTextFile(outputsDir.resolve("confusion_matrices.csv"), cmCsv.mkString("\n"))

      // Identify best model (rank by ROC-AUC + Positive-Class F1 balanced score)
      val bestResult = results.maxBy(r => (r.rocAuc, r.posF1, r.weightedF1))
      log(s"\nBest Performing Model: ${bestResult.modelName} (ROC-AUC = ${f"${bestResult.rocAuc}%.4f"}, Pos-F1 = ${f"${bestResult.posF1}%.4f"}, Accuracy = ${f"${bestResult.accuracy}%.4f"})")

      // Extract feature importances (from Random Forest & Decision Tree) + LR coefficients
      val lrStage = results.head.pipelineModel.stages(3).asInstanceOf[LogisticRegressionModel]
      val dtStage = results(1).pipelineModel.stages(3).asInstanceOf[DecisionTreeClassificationModel]
      val rfStage = results(2).pipelineModel.stages(3).asInstanceOf[RandomForestClassificationModel]

      val fiCsv = scala.collection.mutable.ArrayBuffer("Feature,RF_Importance,DT_Importance,LR_Std_Coefficient")
      log("\nFeature Importances & Standardized Logistic Regression Coefficients:")
      FeatureCols.indices.foreach { i =>
        val fName = FeatureCols(i)
        val rfImp = rfStage.featureImportances(i)
        val dtImp = dtStage.featureImportances(i)
        val lrCoef = lrStage.coefficients(i)
        log(f"  $fName%-26s | RF: $rfImp%.4f | DT: $dtImp%.4f | LR Coef: $lrCoef%+.4f")
        fiCsv += f"$fName,$rfImp%.6f,$dtImp%.6f,$lrCoef%.6f"
      }
      writeTextFile(outputsDir.resolve("feature_importances.csv"), fiCsv.mkString("\n"))

      // -----------------------------------------------------------------------
      // 6. Predict Diabetes Status for New Patient Records
      // -----------------------------------------------------------------------
      log(s"\n--- 6. Predictions on New Patient Records Using Best Model (${bestResult.modelName}) ---")
      val newPatients = Seq(
        Row(1.0, 88.0, 68.0, 18.0, 75.0, 23.4, 0.24, 24.0),
        Row(2.0, 108.0, 74.0, 22.0, 95.0, 27.8, 0.35, 31.0),
        Row(4.0, 146.0, 82.0, 31.0, 185.0, 34.6, 0.68, 44.0),
        Row(6.0, 178.0, 88.0, 35.0, 240.0, 39.2, 0.92, 52.0),
        Row(0.0, 128.0, 72.0, 0.0, 0.0, 31.5, 0.45, 36.0), // Tests zero-imputation in pipeline!
        Row(5.0, 165.0, 84.0, 33.0, 210.0, 36.8, 0.81, 49.0)
      )
      val patientSchema = StructType(FeatureCols.map(c => StructField(c, DoubleType, nullable = false)))
      val rawNewPatientsDf = spark.createDataFrame(sc.parallelize(newPatients), patientSchema)
      val cleanNewPatientsDf = ZeroInvalidCols.foldLeft(rawNewPatientsDf) { (df, c) =>
        df.withColumn(c, when(col(c) === 0.0, lit(null).cast(DoubleType)).otherwise(col(c)))
      }

      val patientPreds = bestResult.pipelineModel.transform(cleanNewPatientsDf).collect()
      val predCsv = scala.collection.mutable.ArrayBuffer(
        "Patient_No,Pregnancies,Glucose,BloodPressure,SkinThickness,Insulin,BMI,DPF,Age,Predicted_Outcome,Predicted_Label,Prob_NonDiabetic,Prob_Diabetic"
      )
      patientPreds.zipWithIndex.foreach { case (row, idx) =>
        val probVec = row.getAs[Vector]("probability")
        val pred = row.getAs[Double]("prediction").toInt
        val labelStr = if (pred == 1) "Diabetic (High Risk)" else "Non-Diabetic (Low Risk)"
        val preg = row.getDouble(0)
        val gluc = if (row.isNullAt(1)) 0.0 else row.getDouble(1)
        val bp   = if (row.isNullAt(2)) 0.0 else row.getDouble(2)
        val skin = if (row.isNullAt(3)) 0.0 else row.getDouble(3)
        val ins  = if (row.isNullAt(4)) 0.0 else row.getDouble(4)
        val bmi  = if (row.isNullAt(5)) 0.0 else row.getDouble(5)
        val dpf  = row.getDouble(6)
        val age  = row.getDouble(7)
        log(f"  Patient ${idx + 1}: Gluc=${gluc}%5.1f, BMI=${bmi}%4.1f, Age=${age}%2.0f, Preg=${preg}%1.0f -> Pred=$pred ($labelStr) | P(Diabetes)=${probVec(1) * 100}%5.2f%%")
        predCsv += f"${idx + 1},${preg}%.0f,${gluc}%.1f,${bp}%.1f,${skin}%.1f,${ins}%.1f,${bmi}%.1f,${dpf}%.3f,${age}%.0f,$pred,$labelStr,${probVec(0)}%.4f,${probVec(1)}%.4f"
      }
      writeTextFile(outputsDir.resolve("new_patient_predictions.csv"), predCsv.mkString("\n"))

      // Capture Spark UI REST API metadata
      sc.uiWebUrl.foreach { uiUrl =>
        try {
          val appId = sc.applicationId
          writeTextFile(outputsDir.resolve("spark_ui_jobs.json"),
            scala.io.Source.fromURL(s"$uiUrl/api/v1/applications/$appId/jobs").mkString)
          writeTextFile(outputsDir.resolve("spark_ui_stages.json"),
            scala.io.Source.fromURL(s"$uiUrl/api/v1/applications/$appId/stages").mkString)
          writeTextFile(outputsDir.resolve("spark_ui_sql.json"),
            scala.io.Source.fromURL(s"$uiUrl/api/v1/applications/$appId/sql").mkString)
          log("\nCaptured Spark UI REST API JSON (jobs, stages, sql) to outputs/spark_ui_*.json")
        } catch {
          case e: Exception => log(s"Note: Could not fetch Spark UI JSON: ${e.getMessage}")
        }
      }

      writeTextFile(outputsDir.resolve("execution_report.txt"), report.toString())
      log(s"\nAll outputs written to: $outputsDir")

      if (holdUiSeconds > 0) {
        println(s"\n[Spark UI Hold] Keeping Spark UI alive at ${sc.uiWebUrl.getOrElse("")} for $holdUiSeconds seconds...")
        Thread.sleep(holdUiSeconds * 1000L)
      }
    } finally {
      spark.stop()
    }
  }
}
