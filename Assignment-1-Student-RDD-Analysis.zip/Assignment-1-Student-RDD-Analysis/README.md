# Assignment 1: Student Academic Performance Analysis Using Apache Spark RDDs

## 1. Overview & Scenario
A university maintains academic records across six engineering departments (`CSE`, `AI&DS`, `IT`, `ECE`, `Mechanical`, `Civil`) and eight semesters (`1`–`8`). This project implements distributed student performance analytics using **Scala 2.12.18** and **Apache Spark 3.5.3 Core RDDs**.

> **Dataset Note:** `data/student_academic_performance_synthetic_10000.csv` is a **synthetic** 10,000-row dataset (`Student_ID`, `Name`, `Department`, `Semester`, `Marks`) created for distributed Spark RDD experimentation.

---

## 2. Project Structure

```text
Assignment-1-Student-RDD-Analysis/
├── data/
│   └── student_academic_performance_synthetic_10000.csv
├── project/build.properties
├── scripts/generate_charts.py
├── src/main/scala/edu/university/rdd/
│   ├── Student.scala                   # Student case class & CSV parser
│   └── StudentAcademicAnalysis.scala   # Spark RDD pipeline & DAG experiment
├── build.sbt
├── pom.xml
├── run.ps1
└── README.md
```

---

## 3. Implementation Methodology & Spark Concepts

### 3.1 `Student` Entity & RDD Creation
- `Student` ([Student.scala](src/main/scala/edu/university/rdd/Student.scala)) is defined as a Scala `case class Student(studentId: Int, name: String, department: String, semester: Int, marks: Double)`, which is automatically serializable across Spark tasks and shuffles.
- **Collection RDD (`sc.parallelize`):** Converts 5 in-memory `Student` objects into a 2-partition RDD.
- **File-Backed RDD (`sc.textFile`):** Reads `data/student_academic_performance_synthetic_10000.csv` into 4 partitions, parses lines via `flatMap(Student.fromCsvLine)`, and caches the resulting `RDD[Student]`.

### 3.2 Transformations vs. Actions & Lazy Evaluation
- **Transformations** (`flatMap`, `filter`, `map`, `reduceByKey`, `mapValues`) are **lazy**: they construct an immutable lineage DAG without reading data or launching cluster jobs.
- **Actions** (`count`, `collect`, `aggregate`, `max`) trigger the `DAGScheduler` to materialize the graph into physical stages and tasks.
- Using a `SparkListener`, chaining 6 transformations (`textFile -> flatMap -> filter -> filter -> map -> reduceByKey -> mapValues`) took **`41.827 ms`** with **`0` Spark jobs**, whereas invoking `.collect()` triggered **`2` Spark jobs** in **`138.370 ms`**.

### 3.3 DAG Execution & Distributed Cluster Processing
1. **Stage Splitting (`toDebugString`):** Narrow transformations (`textFile -> flatMap -> filter -> map`) operate partition-by-partition without data movement and are pipelined into **Stage 0**. The wide transformation `reduceByKey` introduces a `ShuffleDependency`, forming a **Stage boundary** before **Stage 1** (`ShuffledRDD -> mapValues`).
2. **Map-Side Pre-Aggregation:** Unlike `groupByKey`, `reduceByKey` combines partial counts/sums locally within each partition before shuffling across the network.
3. **Cluster Scheduling:** The Driver's `DAGScheduler` hands stage task sets to `TaskScheduler`, which schedules one task per partition (`4` tasks per stage) across available executor threads (`local[*]` uses 16 threads on the test machine).

---

## 4. Verified Results (10,000 Synthetic Records)

- **Total Student Records Loaded:** `10,000` across `4` partitions
- **Students Scoring `> 75` Marks:** `3,736` (`37.36%`)
- **Overall Average Marks:** `70.3940` (Total Marks Sum = `703,939.71`)
- **Highest Marks Achieved:** `100.00` (**166 students** tied at `100.00`; `max()(Ordering.by(_.marks))` returned `Student(107512, Dev Kumar, ECE, 7, 100.0)`)

### Department-wise Summary (`reduceByKey` & `aggregateByKey`)
| Department | Students | Share (%) | Average Marks | Min Marks | Max Marks | `> 75` Count | `> 75` Rate |
|---|---:|---:|---:|---:|---:|---:|---:|
| **IT** | 1,788 | 17.88% | **70.7921** | 29.73 | 100.00 | 698 | 39.04% |
| **ECE** | 1,709 | 17.09% | 70.5547 | 18.20 | 100.00 | 661 | 38.68% |
| **AI&DS** | 2,017 | 20.17% | 70.5203 | 20.57 | 100.00 | 750 | 37.18% |
| **Civil** | 887 | 8.87% | 70.2389 | 19.81 | 100.00 | 326 | 36.75% |
| **Mechanical** | 1,175 | 11.75% | 70.0990 | 22.72 | 100.00 | 423 | 36.00% |
| **CSE** | 2,424 | 24.24% | 70.0816 | 24.40 | 100.00 | 878 | 36.22% |

### Sample Captured DAG Lineage (`RDD.toDebugString`)
```text
(4) MapPartitionsRDD[43] at mapValues at StudentAcademicAnalysis.scala:261 []
 |  ShuffledRDD[42] at reduceByKey at StudentAcademicAnalysis.scala:260 []
 +-(4) MapPartitionsRDD[41] at map at StudentAcademicAnalysis.scala:259 []
    |  MapPartitionsRDD[40] at filter at StudentAcademicAnalysis.scala:258 []
    |  MapPartitionsRDD[39] at filter at StudentAcademicAnalysis.scala:257 []
    |  MapPartitionsRDD[38] at flatMap at StudentAcademicAnalysis.scala:256 []
    |  ...\data\student_academic_performance_synthetic_10000.csv MapPartitionsRDD[37] at textFile []
    |  ...\data\student_academic_performance_synthetic_10000.csv HadoopRDD[36] at textFile []
```

---

## 5. How to Build and Run

```bash
cd Assignment-1-Student-RDD-Analysis

# Option 1: sbt
sbt run

# Option 2: Apache Maven (Java 17)
mvn compile exec:java

# Option 3: PowerShell + Scala CLI (Windows)
.\run.ps1
```

To keep the Spark UI alive on `http://localhost:4040` for inspection, pass `-- --hold-ui 30` (Scala CLI) or `--hold-ui 30`. To generate visualizations from `outputs/`, run `python scripts/generate_charts.py`.
