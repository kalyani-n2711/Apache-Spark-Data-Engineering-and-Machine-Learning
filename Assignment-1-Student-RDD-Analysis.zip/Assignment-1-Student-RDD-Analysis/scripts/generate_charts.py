import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

plt.rcParams.update({
    "figure.dpi": 160,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
})

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE_DIR, "outputs")
CHART_DIR = os.path.join(OUT_DIR, "charts")
os.makedirs(CHART_DIR, exist_ok=True)

dept_df = pd.read_csv(os.path.join(OUT_DIR, "department_statistics.csv"))
sem_df = pd.read_csv(os.path.join(OUT_DIR, "semester_statistics.csv"))
students_df = pd.read_csv(os.path.join(BASE_DIR, "data", "student_academic_performance_synthetic_10000.csv"))

# 1. Department Student Distribution & Average Marks
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.2))
dept_sorted_cnt = dept_df.sort_values("Student_Count", ascending=True)
other_cnt = dept_sorted_cnt["Student_Count"] - dept_sorted_cnt["High_Scorers_GT75"]

ax1.barh(dept_sorted_cnt["Department"], dept_sorted_cnt["High_Scorers_GT75"],
         color="#2b6cb0", label="Marks > 75")
ax1.barh(dept_sorted_cnt["Department"], other_cnt,
         left=dept_sorted_cnt["High_Scorers_GT75"], color="#a0aec0", label="Marks <= 75")
for idx, row in enumerate(dept_sorted_cnt.itertuples()):
    ax1.text(row.Student_Count + 35, idx, f"{row.Student_Count:,} ({row.High_Scorer_Percent:.1f}% >75)",
             va="center", fontsize=9)
ax1.set_xlim(0, dept_sorted_cnt["Student_Count"].max() * 1.32)
ax1.set_title("Students per Department (Total = 10,000)", fontweight="bold", pad=10)
ax1.set_xlabel("Number of Students")
ax1.legend(loc="lower right", frameon=False)

dept_sorted_avg = dept_df.sort_values("Average_Marks", ascending=True)
colors = ["#38a169" if v >= students_df["Marks"].mean() else "#718096" for v in dept_sorted_avg["Average_Marks"]]
ax2.barh(dept_sorted_avg["Department"], dept_sorted_avg["Average_Marks"], color=colors, height=0.55)
overall_mean = students_df["Marks"].mean()
ax2.axvline(overall_mean, color="#e53e3e", linestyle="--", linewidth=1.4, label=f"Overall Mean ({overall_mean:.2f})")
for idx, row in enumerate(dept_sorted_avg.itertuples()):
    ax2.text(row.Average_Marks + 0.15, idx, f"{row.Average_Marks:.2f}", va="center", fontsize=9, fontweight="bold")
ax2.set_xlim(65, 73)
ax2.set_title("Department-wise Average Marks", fontweight="bold", pad=10)
ax2.set_xlabel("Average Marks (out of 100)")
ax2.legend(loc="lower right", frameon=False)

fig.suptitle("Assignment 1 (Spark RDDs): Department Enrollment & Academic Performance", fontsize=13, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "01_department_distribution_and_avg_marks.png"), bbox_inches="tight")
plt.close()

# 2. Marks Distribution Histogram & Semester Trend
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.0))
ax1.hist(students_df["Marks"], bins=30, color="#4299e1", edgecolor="white", alpha=0.88)
ax1.axvline(75.0, color="#2f855a", linestyle="--", linewidth=1.8, label="Distinction Threshold (75.0)")
ax1.axvline(overall_mean, color="#e53e3e", linestyle=":", linewidth=1.8, label=f"Mean ({overall_mean:.2f})")
ax1.set_title("Marks Distribution Across 10,000 Students", fontweight="bold", pad=10)
ax1.set_xlabel("Marks")
ax1.set_ylabel("Number of Students")
ax1.legend(frameon=False)

ax2.plot(sem_df["Semester"], sem_df["Average_Marks"], marker="o", linewidth=2.2, color="#2b6cb0", markersize=7)
for row in sem_df.itertuples():
    ax2.annotate(f"{row.Average_Marks:.2f}", (row.Semester, row.Average_Marks),
                 textcoords="offset points", xytext=(0, 8), ha="center", fontsize=8.5)
ax2.set_xticks(sem_df["Semester"])
ax2.set_ylim(sem_df["Average_Marks"].min() - 1.0, sem_df["Average_Marks"].max() + 1.2)
ax2.set_title("Semester-wise Average Marks", fontweight="bold", pad=10)
ax2.set_xlabel("Semester")
ax2.set_ylabel("Average Marks")
ax2.grid(axis="y", linestyle="--", alpha=0.35)

fig.suptitle("Assignment 1 (Spark RDDs): Score Distribution & Semester Performance", fontsize=13, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "02_marks_distribution_and_semester_trend.png"), bbox_inches="tight")
plt.close()

# 3. Spark RDD DAG & Cluster Execution Architecture Diagram
fig, ax = plt.subplots(figsize=(13, 6.2))
ax.set_xlim(0, 13)
ax.set_ylim(0, 6.5)
ax.axis("off")

ax.text(6.5, 6.15, "Spark RDD DAG Lineage & Stage Boundaries (Assignment 1)", ha="center", fontsize=13, fontweight="bold")

# Stage 0 box
s0 = patches.FancyBboxPatch((0.3, 3.0), 7.6, 2.7, boxstyle="round,pad=0.12", facecolor="#ebf8ff", edgecolor="#3182ce", linewidth=1.6)
ax.add_patch(s0)
ax.text(4.1, 5.45, "Stage 0: Narrow Transformations (Pipelined in Each Partition)", ha="center", fontweight="bold", color="#2c5282")

nodes_s0 = [
    (0.55, 3.6, 1.55, 1.3, "HadoopRDD\nsc.textFile()\n[4 Partitions]"),
    (2.35, 3.6, 1.55, 1.3, "MapPartitionsRDD\nflatMap(\nStudent.fromCsv)"),
    (4.15, 3.6, 1.55, 1.3, "MapPartitionsRDD\nfilter(marks>75)\nfilter(sem>=5)"),
    (5.95, 3.6, 1.65, 1.3, "MapPartitionsRDD\nmap(s =>\n(dept,(marks,1)))"),
]
for x, y, w, h, label in nodes_s0:
    box = patches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08", facecolor="white", edgecolor="#4299e1", linewidth=1.2)
    ax.add_patch(box)
    ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontsize=8.5)

for x1, x2 in [(2.12, 2.33), (3.92, 4.13), (5.72, 5.93)]:
    ax.annotate("", xy=(x2, 4.25), xytext=(x1, 4.25), arrowprops=dict(arrowstyle="->", lw=1.6, color="#2b6cb0"))

# Shuffle boundary
ax.plot([8.25, 8.25], [2.8, 5.8], color="#e53e3e", linestyle="--", linewidth=2.0)
ax.text(8.25, 2.55, "SHUFFLE BOUNDARY\n(reduceByKey:\nMap-side combine\n+ Network Exchange)", ha="center", va="top", fontsize=8.5, color="#c53030", fontweight="bold")

# Stage 1 box
s1 = patches.FancyBboxPatch((8.65, 3.0), 4.05, 2.7, boxstyle="round,pad=0.12", facecolor="#f0fff4", edgecolor="#38a169", linewidth=1.6)
ax.add_patch(s1)
ax.text(10.67, 5.45, "Stage 1: Wide Shuffle & Action", ha="center", fontweight="bold", color="#22543d")

nodes_s1 = [
    (8.85, 3.6, 1.65, 1.3, "ShuffledRDD\nreduceByKey\n(Dept Aggregation)"),
    (10.8, 3.6, 1.65, 1.3, "MapPartitionsRDD\nmapValues(avg)\n-> collect() Action"),
]
for x, y, w, h, label in nodes_s1:
    box = patches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08", facecolor="white", edgecolor="#38a169", linewidth=1.2)
    ax.add_patch(box)
    ax.text(x + w / 2, y + h / 2, label, ha="center", va="center", fontsize=8.5)

ax.annotate("", xy=(8.83, 4.25), xytext=(7.65, 4.25), arrowprops=dict(arrowstyle="->", lw=1.8, color="#c53030"))
ax.annotate("", xy=(10.78, 4.25), xytext=(10.52, 4.25), arrowprops=dict(arrowstyle="->", lw=1.6, color="#2f855a"))

# Cluster distribution summary box at bottom
cluster_box = patches.FancyBboxPatch((0.3, 0.3), 12.4, 1.45, boxstyle="round,pad=0.1", facecolor="#f7fafc", edgecolor="#718096", linewidth=1.2)
ax.add_patch(cluster_box)
ax.text(6.5, 1.45, "Distributed Execution Model (Driver -> Cluster Manager -> Executors -> Partitions)", ha="center", fontweight="bold", fontsize=10, color="#2d3748")
ax.text(6.5, 0.8,
        "1. Lazy Evaluation: Transformations build DAG nodes in 34.6 ms (0 Spark Jobs) without reading CSV data.\n"
        "2. Action Trigger: collect() submits DAG to DAGScheduler -> splits on ShuffleDependency into Stage 0 & Stage 1.\n"
        "3. Task Distribution: TaskScheduler dispatches 4 Stage-0 tasks + 4 Stage-1 tasks across local[*] executor cores.",
        ha="center", va="center", fontsize=9, color="#4a5568")

plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "03_spark_rdd_dag_architecture.png"), bbox_inches="tight")
plt.close()
print("Generated StudentRDDProject charts successfully.")
