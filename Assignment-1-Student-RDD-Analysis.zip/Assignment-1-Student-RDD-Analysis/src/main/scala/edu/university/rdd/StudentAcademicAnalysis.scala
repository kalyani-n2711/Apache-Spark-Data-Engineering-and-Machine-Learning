//> using scala 2.12.18
//> using dep org.apache.spark::spark-core:3.5.3
//> using dep org.apache.spark::spark-sql:3.5.3
//> using javaOpt --add-opens=java.base/java.lang=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.lang.invoke=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.lang.reflect=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.io=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.net=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.nio=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util.concurrent=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/java.util.concurrent.atomic=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.nio.ch=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.nio.cs=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.security.action=ALL-UNNAMED
//> using javaOpt --add-opens=java.base/sun.util.calendar=ALL-UNNAMED
//> using javaOpt --add-opens=java.security.jgss/sun.security.krb5=ALL-UNNAMED

package edu.university.rdd

import java.nio.charset.StandardCharsets
import java.nio.file.{Files, Path, Paths}
import java.util.concurrent.atomic.AtomicInteger
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD
import org.apache.spark.scheduler.{SparkListener, SparkListenerJobStart}

/**
 * Assignment 1: Student Academic Performance Analysis Using Apache Spark RDDs
 *
 * Demonstrates:
 *  1. Defining the Student entity class and creating RDDs from both an in-memory
 *     Scala collection (sc.parallelize) and the 10,000-row CSV dataset (sc.textFile).
 *  2. Core RDD operations: display records, filter (> 75 marks), count per department,
 *     overall and department-wise average marks, and highest-scoring student(s).
 *  3. Transformations vs Actions and Lazy Evaluation with live SparkListener job tracking.
 *  4. DAG lineage inspection (toDebugString) and Spark UI / REST metrics capture.
 */
object StudentAcademicAnalysis {

  private case class DeptStats(sum: Double, count: Long, min: Double, max: Double, gt75Count: Long) {
    def avg: Double = if (count == 0) 0.0 else sum / count
  }

  private def resolveInputPath(cliArg: Option[String]): Path = {
    val candidates = cliArg.toSeq ++ Seq(
      "data/student_academic_performance_synthetic_10000.csv",
      "Assignment-1-Student-RDD-Analysis/data/student_academic_performance_synthetic_10000.csv",
      "student_academic_performance_synthetic_10000.csv"
    )
    candidates
      .map(p => Paths.get(p).toAbsolutePath.normalize())
      .find(Files.exists(_))
      .getOrElse {
        throw new IllegalArgumentException(
          s"Could not locate data/student_academic_performance_synthetic_10000.csv. Checked: ${candidates.mkString(", ")}"
        )
      }
  }

  private def writeTextFile(path: Path, content: String): Unit = {
    Files.createDirectories(path.getParent)
    Files.write(path, content.getBytes(StandardCharsets.UTF_8))
  }

  def main(args: Array[String]): Unit = {
    val argList = args.toList
    val csvArg = argList.find(a => !a.startsWith("--"))
    val holdUiSeconds = argList
      .sliding(2)
      .collectFirst { case List("--hold-ui", secs) => secs.toInt }
      .getOrElse(0)

    val inputPath = resolveInputPath(csvArg)
    val projectDir =
      if (inputPath.getParent.getFileName.toString == "data") inputPath.getParent.getParent
      else inputPath.getParent
    val outputsDir = projectDir.resolve("outputs")
    Files.createDirectories(outputsDir)

    val conf = new SparkConf()
      .setAppName("Assignment1-StudentAcademicPerformance-RDD")
      .setMaster("local[*]")
      .set("spark.ui.enabled", "true")
      .set("spark.ui.port", "4040")

    val sc = new SparkContext(conf)
    sc.setLogLevel("WARN")

    val jobCounter = new AtomicInteger(0)
    sc.addSparkListener(new SparkListener {
      override def onJobStart(jobStart: SparkListenerJobStart): Unit = {
        jobCounter.incrementAndGet()
      }
    })

    val report = new StringBuilder()
    def log(msg: String): Unit = {
      println(msg)
      report.append(msg).append("\n")
    }

    try {
      log("=" * 80)
      log("ASSIGNMENT 1: STUDENT ACADEMIC PERFORMANCE ANALYSIS USING APACHE SPARK RDDs")
      log("=" * 80)
      log(s"Spark Version      : ${sc.version}")
      log(s"Master             : ${sc.master}")
      log(s"Default Parallelism: ${sc.defaultParallelism}")
      log(s"Spark Web UI       : ${sc.uiWebUrl.getOrElse("Disabled")}")
      log(s"Dataset Path       : $inputPath")

      // -----------------------------------------------------------------------
      // Task 1 & 2a: Create multiple Student objects in memory & parallelize RDD
      // -----------------------------------------------------------------------
      log("\n--- 1. In-Memory Student Collection -> RDD (sc.parallelize) ---")
      val sampleStudents: Seq[Student] = Seq(
        Student(200001, "Aarav Kulkarni", "CSE", 4, 88.5),
        Student(200002, "Diya Nair", "AI&DS", 6, 93.2),
        Student(200003, "Rohan Kapoor", "ECE", 2, 67.4),
        Student(200004, "Meera Iyer", "IT", 8, 79.8),
        Student(200005, "Kabir Joshi", "Mechanical", 5, 72.1)
      )
      val sampleRdd: RDD[Student] = sc.parallelize(sampleStudents, numSlices = 2)
      log(s"In-memory Sample RDD Partitions: ${sampleRdd.getNumPartitions}")
      sampleRdd.collect().foreach(s => log(f"  ${s.studentId}%6d | ${s.name}%-16s | ${s.department}%-10s | Sem ${s.semester} | ${s.marks}%6.2f"))

      // -----------------------------------------------------------------------
      // Task 2b: Load the 10,000-row CSV dataset into an RDD[Student]
      // -----------------------------------------------------------------------
      log("\n--- 2. Loading 10,000-Row CSV Dataset into RDD[Student] ---")
      val rawLinesRdd: RDD[String] = sc.textFile(inputPath.toString, minPartitions = 4)
      val studentsRdd: RDD[Student] = rawLinesRdd
        .flatMap(Student.fromCsvLine)
        .cache() // Cache after parsing so subsequent actions reuse parsed Student objects

      val totalStudents = studentsRdd.count()
      log(s"Total Student Records Loaded : $totalStudents")
      log(s"RDD Partitions               : ${studentsRdd.getNumPartitions}")

      // Task 3a: Display all student records (print preview + export full 10,000 rows)
      log("\n--- 3a. Display Student Records (Sample of 15 shown; full 10,000 exported) ---")
      val allCollected: Array[Student] = studentsRdd.collect()
      allCollected.take(15).foreach { s =>
        log(f"  ${s.studentId}%6d | ${s.name}%-22s | ${s.department}%-10s | Sem ${s.semester} | ${s.marks}%6.2f")
      }
      val allDumpCsv = ("Student_ID,Name,Department,Semester,Marks" +: allCollected.map(_.toCsvRow)).mkString("\n")
      writeTextFile(outputsDir.resolve("all_students_verified.csv"), allDumpCsv)
      log(s"Exported all ${allCollected.length} records to outputs/all_students_verified.csv")

      // Task 3b: Filter students who scored more than 75 marks
      log("\n--- 3b. Students Scoring More Than 75 Marks (marks > 75.0) ---")
      val highScorersRdd: RDD[Student] = studentsRdd.filter(_.marks > 75.0)
      val highScorers: Array[Student] = highScorersRdd.sortBy(s => (-s.marks, s.studentId)).collect()
      val highScorerPct = (highScorers.length.toDouble / totalStudents) * 100.0
      log(f"Count of students with Marks > 75: ${highScorers.length} (${highScorerPct}%.2f%% of $totalStudents)")
      log("Top 10 High Scorers:")
      highScorers.take(10).foreach { s =>
        log(f"  ${s.studentId}%6d | ${s.name}%-22s | ${s.department}%-10s | Sem ${s.semester} | ${s.marks}%6.2f")
      }
      val highCsv = ("Student_ID,Name,Department,Semester,Marks" +: highScorers.map(_.toCsvRow)).mkString("\n")
      writeTextFile(outputsDir.resolve("high_scorers_gt75.csv"), highCsv)

      // Task 3c: Total number of students in each department
      log("\n--- 3c. Total Number of Students per Department (reduceByKey) ---")
      val deptCounts: Array[(String, Int)] = studentsRdd
        .map(s => (s.department, 1))
        .reduceByKey(_ + _)
        .sortBy(-_._2)
        .collect()
      deptCounts.foreach { case (dept, cnt) =>
        val pct = (cnt.toDouble / totalStudents) * 100.0
        log(f"  $dept%-12s : $cnt%5d students ($pct%5.2f%%)")
      }
      val deptCountsCsv = ("Department,Student_Count,Share_Percent" +:
        deptCounts.map { case (d, c) => f"$d,$c,${(c.toDouble / totalStudents) * 100.0}%.2f" }).mkString("\n")
      writeTextFile(outputsDir.resolve("department_counts.csv"), deptCountsCsv)

      // Task 3d: Average marks of students (overall + department-wise + semester-wise)
      log("\n--- 3d. Average Marks (Overall via aggregate, Department-wise via aggregateByKey) ---")
      val (sumMarks, countMarks) = studentsRdd.aggregate((0.0, 0L))(
        seqOp = { case ((accSum, accCnt), s) => (accSum + s.marks, accCnt + 1L) },
        combOp = { case ((s1, c1), (s2, c2)) => (s1 + s2, c1 + c2) }
      )
      val overallAvg = sumMarks / countMarks
      log(f"Overall Average Marks across $countMarks students: $overallAvg%.4f (Total Marks Sum = $sumMarks%.2f)")

      val zeroDept = DeptStats(0.0, 0L, Double.MaxValue, Double.MinValue, 0L)
      val deptStatsRdd: RDD[(String, DeptStats)] = studentsRdd
        .map(s => (s.department, s.marks))
        .aggregateByKey(zeroDept)(
          seqOp = (st, m) => DeptStats(
            sum = st.sum + m,
            count = st.count + 1L,
            min = math.min(st.min, m),
            max = math.max(st.max, m),
            gt75Count = st.gt75Count + (if (m > 75.0) 1L else 0L)
          ),
          combOp = (a, b) => DeptStats(
            sum = a.sum + b.sum,
            count = a.count + b.count,
            min = math.min(a.min, b.min),
            max = math.max(a.max, b.max),
            gt75Count = a.gt75Count + b.gt75Count
          )
        )

      val deptStatsSorted = deptStatsRdd.sortBy(-_._2.avg).collect()
      log("Department-wise Performance Summary:")
      log(f"  ${"Department"}%-12s | ${"Count"}%6s | ${"Avg Marks"}%10s | ${"Min"}%7s | ${"Max"}%7s | ${">75 Count"}%9s | ${">75 %"}%7s")
      log("  " + "-" * 74)
      deptStatsSorted.foreach { case (dept, st) =>
        val gt75Pct = (st.gt75Count.toDouble / st.count) * 100.0
        log(f"  $dept%-12s | ${st.count}%6d | ${st.avg}%10.4f | ${st.min}%7.2f | ${st.max}%7.2f | ${st.gt75Count}%9d | $gt75Pct%6.2f%%")
      }
      val deptStatsCsv = ("Department,Student_Count,Average_Marks,Min_Marks,Max_Marks,High_Scorers_GT75,High_Scorer_Percent" +:
        deptStatsSorted.map { case (d, st) =>
          f"$d,${st.count},${st.avg}%.4f,${st.min}%.2f,${st.max}%.2f,${st.gt75Count},${(st.gt75Count.toDouble / st.count) * 100.0}%.2f"
        }).mkString("\n")
      writeTextFile(outputsDir.resolve("department_statistics.csv"), deptStatsCsv)

      // Semester-wise statistics for deeper academic insight
      val semStatsSorted = studentsRdd
        .map(s => (s.semester, (s.marks, 1L)))
        .reduceByKey { case ((s1, c1), (s2, c2)) => (s1 + s2, c1 + c2) }
        .mapValues { case (s, c) => (c, s / c) }
        .sortByKey()
        .collect()
      val semStatsCsv = ("Semester,Student_Count,Average_Marks" +:
        semStatsSorted.map { case (sem, (cnt, avg)) => f"$sem,$cnt,$avg%.4f" }).mkString("\n")
      writeTextFile(outputsDir.resolve("semester_statistics.csv"), semStatsCsv)

      // Task 3e: Identify the student(s) with the highest marks
      log("\n--- 3e. Student(s) with Highest Marks ---")
      val topSingleStudent = studentsRdd.max()(Ordering.by(_.marks))
      val maxMarksValue = topSingleStudent.marks
      val allTopStudents = studentsRdd.filter(_.marks == maxMarksValue).sortBy(_.studentId).collect()
      log(f"Maximum Marks Achieved: $maxMarksValue%.2f")
      log(s"Single max() result   : $topSingleStudent")
      log(s"Total students tied at maximum marks ($maxMarksValue): ${allTopStudents.length}")
      allTopStudents.foreach { s =>
        log(f"  ${s.studentId}%6d | ${s.name}%-22s | ${s.department}%-10s | Sem ${s.semester} | ${s.marks}%6.2f")
      }
      val topCsv = ("Student_ID,Name,Department,Semester,Marks" +: allTopStudents.map(_.toCsvRow)).mkString("\n")
      writeTextFile(outputsDir.resolve("top_scorers.csv"), topCsv)

      // -----------------------------------------------------------------------
      // Task 4 & 5: Transformations vs Actions & Lazy Evaluation Demonstration
      // -----------------------------------------------------------------------
      log("\n--- 4 & 5. Transformations vs Actions & Lazy Evaluation Experiment ---")
      val jobsBeforeTransformations = jobCounter.get()
      val t0 = System.nanoTime()

      // Chained transformations (NO Spark job is triggered here!)
      val freshRaw = sc.textFile(inputPath.toString, minPartitions = 4)
      val step1Parsed = freshRaw.flatMap(Student.fromCsvLine)
      val step2FilteredMarks = step1Parsed.filter(_.marks > 75.0)
      val step3SeniorSem = step2FilteredMarks.filter(_.semester >= 5)
      val step4Keyed = step3SeniorSem.map(s => (s.department, (s.marks, 1L)))
      val step5Reduced = step4Keyed.reduceByKey { case ((s1, c1), (s2, c2)) => (s1 + s2, c1 + c2) }
      val step6Formatted = step5Reduced.mapValues { case (s, c) => s / c }

      val transformDurationMs = (System.nanoTime() - t0) / 1e6
      val jobsAfterTransformations = jobCounter.get()

      log(f"After defining 6 chained transformations (textFile -> flatMap -> filter -> filter -> map -> reduceByKey -> mapValues):")
      log(f"  Elapsed wall time     : $transformDurationMs%.3f ms (instantaneous DAG construction)")
      log(f"  Spark Jobs Triggered  : ${jobsAfterTransformations - jobsBeforeTransformations} (LAZY EVALUATION!)")

      val tAction1 = System.nanoTime()
      val seniorHighSummary = step6Formatted.sortBy(-_._2).collect()
      val actionDurationMs = (System.nanoTime() - tAction1) / 1e6
      val jobsAfterAction = jobCounter.get()

      log(f"After calling action .collect() on the final transformed RDD:")
      log(f"  Elapsed wall time     : $actionDurationMs%.3f ms (actual execution across partitions)")
      log(f"  Spark Jobs Triggered  : ${jobsAfterAction - jobsAfterTransformations}")
      log("Senior Semester (>= 5) High-Scorers (> 75) Dept Averages:")
      seniorHighSummary.foreach { case (d, avg) => log(f"  $d%-12s : $avg%.4f") }

      // -----------------------------------------------------------------------
      // Task 6: DAG Lineage Examination (toDebugString)
      // -----------------------------------------------------------------------
      log("\n--- 6. Spark DAG Lineage (RDD.toDebugString) ---")
      val narrowDebug = step3SeniorSem.toDebugString
      val wideDebug = step6Formatted.toDebugString
      log("Narrow-Only Pipeline Lineage (no shuffle):")
      log(narrowDebug)
      log("\nWide-Shuffle Pipeline Lineage (reduceByKey creates ShuffleDependency -> Stage boundary):")
      log(wideDebug)

      val dagText =
        s"""=== NARROW TRANSFORMATIONS LINEAGE ===
           |$narrowDebug
           |
           |=== WIDE TRANSFORMATION (reduceByKey) LINEAGE ===
           |$wideDebug
           |""".stripMargin
      writeTextFile(outputsDir.resolve("dag_lineage.txt"), dagText)

      // Capture Spark UI REST API JSON if UI is active
      sc.uiWebUrl.foreach { uiUrl =>
        try {
          val appsJson = scala.io.Source.fromURL(s"$uiUrl/api/v1/applications").mkString
          writeTextFile(outputsDir.resolve("spark_ui_apps.json"), appsJson)
          val appId = sc.applicationId
          val jobsJson = scala.io.Source.fromURL(s"$uiUrl/api/v1/applications/$appId/jobs").mkString
          val stagesJson = scala.io.Source.fromURL(s"$uiUrl/api/v1/applications/$appId/stages").mkString
          writeTextFile(outputsDir.resolve("spark_ui_jobs.json"), jobsJson)
          writeTextFile(outputsDir.resolve("spark_ui_stages.json"), stagesJson)
          log(s"\nCaptured live Spark UI REST API metadata (jobs & stages) to outputs/spark_ui_*.json")
        } catch {
          case e: Exception => log(s"Note: Could not fetch Spark UI JSON: ${e.getMessage}")
        }
      }

      // Save full console execution summary
      writeTextFile(outputsDir.resolve("execution_report.txt"), report.toString())
      log(s"\nAll outputs written to: $outputsDir")

      if (holdUiSeconds > 0) {
        println(s"\n[Spark UI Hold] Keeping Spark UI alive at ${sc.uiWebUrl.getOrElse("")} for $holdUiSeconds seconds...")
        Thread.sleep(holdUiSeconds * 1000L)
      }
    } finally {
      sc.stop()
    }
  }
}
