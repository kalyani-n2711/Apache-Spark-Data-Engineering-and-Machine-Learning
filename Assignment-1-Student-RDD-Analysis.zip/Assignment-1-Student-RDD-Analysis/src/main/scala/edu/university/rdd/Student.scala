package edu.university.rdd

/**
 * Entity class representing a university student's academic record.
 * Serializable by default as a Scala case class for Spark RDD distribution.
 */
case class Student(
    studentId: Int,
    name: String,
    department: String,
    semester: Int,
    marks: Double
) {
  def toCsvRow: String =
    s"$studentId,${escapeCsv(name)},${escapeCsv(department)},$semester,$marks"

  private def escapeCsv(value: String): String =
    if (value.contains(",") || value.contains("\"")) {
      "\"" + value.replace("\"", "\"\"") + "\""
    } else {
      value
    }
}

object Student {
  /** Parse one CSV line (without header) into Option[Student]. */
  def fromCsvLine(line: String): Option[Student] = {
    val trimmed = line.trim
    if (trimmed.isEmpty || trimmed.startsWith("Student_ID")) None
    else {
      val parts = trimmed.split(",", -1).map(_.trim)
      if (parts.length >= 5) {
        try {
          Some(
            Student(
              studentId = parts(0).toInt,
              name = parts(1),
              department = parts(2),
              semester = parts(3).toInt,
              marks = parts(4).toDouble
            )
          )
        } catch {
          case _: NumberFormatException => None
        }
      } else None
    }
  }
}
